import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import { useStore } from '../lib/store';
import Header from '../components/Header';
import Footer from '../components/Footer';
import CouponInput from '../components/CouponInput';
import {
  Star, ShoppingCart, Heart, Download,
  Clock, Users, Award, CheckCircle,
  ArrowRight, Minus, Plus, X
} from 'lucide-react';

const ProductDetail: React.FC = () => {
  const { isRTL } = useLanguage();
  const { addToCart } = useStore();
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'description' | 'reviews' | 'content'>('description');
  const [reviewText, setReviewText] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviews, setReviews] = useState([
    { id: 1, user: isRTL ? 'أحمد محمد' : 'Ahmed M.', rating: 5, text: isRTL ? 'منتج ممتاز! استفدت منه كثيراً في عملي.' : 'Excellent product! Helped me a lot in my work.', date: '2024-01-10' },
    { id: 2, user: isRTL ? 'سارة علي' : 'Sara A.', rating: 5, text: isRTL ? 'أفضل استثمار قمت به هذا العام.' : 'Best investment I made this year.', date: '2024-01-08' },
    { id: 3, user: isRTL ? 'خالد العتيبي' : 'Khaled A.', rating: 4, text: isRTL ? 'محتوى رائع لكن يحتاج مزيد من الأمثلة.' : 'Great content but needs more examples.', date: '2024-01-05' },
  ]);

  const product = {
    id: '1',
    name: isRTL ? 'دورة BIM المتقدمة' : 'Advanced BIM Course',
    price: 499,
    oldPrice: 799,
    rating: 4.9,
    reviewsCount: 256,
    students: 1250,
    duration: isRTL ? '40 ساعة' : '40 hours',
    image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800',
    category: isRTL ? 'دورات' : 'Courses',
    features: [
      isRTL ? '40+ ساعة فيديو عالي الجودة' : '40+ hours of HD video',
      isRTL ? 'ملفات مشروع كاملة' : 'Complete project files',
      isRTL ? 'شهادة معتمدة' : 'Certified certificate',
      isRTL ? 'دعم مباشر من المدرب' : 'Direct instructor support',
      isRTL ? 'وصول مدى الحياة' : 'Lifetime access',
      isRTL ? 'تحديثات مجانية' : 'Free updates',
    ],
    description: isRTL 
      ? 'تعلم Revit وNavisworks وTekla في دورة شاملة تأخذك من المبتدئ إلى المحترف. ستتعلم كيفية إنشاء نماذج BIM احترافية وإدارة المشاريع بكفاءة.'
      : 'Learn Revit, Navisworks, and Tekla in a comprehensive course that takes you from beginner to professional. You will learn how to create professional BIM models and manage projects efficiently.',
  };

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      quantity: quantity,
      image: product.image,
    });
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewText.trim()) return;
    setReviews([
      { id: Date.now(), user: isRTL ? 'أنت' : 'You', rating: reviewRating, text: reviewText, date: new Date().toISOString().split('T')[0] },
      ...reviews,
    ]);
    setReviewText('');
    setReviewRating(5);
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="pt-32 pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Product Image */}
            <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }}>
              <div className="relative rounded-2xl overflow-hidden">
                <img src={product.image} alt={product.name} className="w-full h-96 object-cover" />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-amber-500 text-slate-950 text-sm font-bold rounded-full">
                    {product.category}
                  </span>
                </div>
                {product.oldPrice && (
                  <div className="absolute top-4 right-4">
                    <span className="px-3 py-1 bg-red-500 text-white text-sm font-bold rounded-full">
                      {Math.round((1 - product.price / product.oldPrice) * 100)}% OFF
                    </span>
                  </div>
                )}
              </div>
            </motion.div>

            {/* Product Info */}
            <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }}>
              <h1 className="text-3xl font-bold text-white mb-4">{product.name}</h1>
              
              <div className="flex items-center gap-4 mb-6">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`w-5 h-5 ${i < Math.floor(product.rating) ? 'text-amber-400 fill-amber-400' : 'text-slate-600'}`} />
                  ))}
                </div>
                <span className="text-white font-medium">{product.rating}</span>
                <span className="text-slate-400">({product.reviewsCount} {isRTL ? 'تقييم' : 'reviews'})</span>
              </div>

              <div className="flex items-center gap-4 mb-6">
                <div className="flex items-center gap-2 text-slate-400">
                  <Users className="w-5 h-5" />
                  <span>{product.students.toLocaleString()} {isRTL ? 'طالب' : 'students'}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400">
                  <Clock className="w-5 h-5" />
                  <span>{product.duration}</span>
                </div>
              </div>

              <div className="flex items-center gap-4 mb-6">
                <span className="text-4xl font-bold text-amber-400">${product.price}</span>
                {product.oldPrice && (
                  <span className="text-xl text-slate-500 line-through">${product.oldPrice}</span>
                )}
              </div>

              <div className="space-y-3 mb-6">
                {product.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-400" />
                    <span className="text-slate-300">{feature}</span>
                  </div>
                ))}
              </div>

              {/* Quantity & Add to Cart */}
              <div className="flex items-center gap-4 mb-6">
                <div className="flex items-center gap-2 bg-slate-800 rounded-lg p-1">
                  <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="p-2 text-slate-400 hover:text-white">
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="w-10 text-center text-white font-medium">{quantity}</span>
                  <button onClick={() => setQuantity(quantity + 1)} className="p-2 text-slate-400 hover:text-white">
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
                <motion.button
                  onClick={handleAddToCart}
                  className="flex-1 flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <ShoppingCart className="w-5 h-5" />
                  {isRTL ? 'أضف للسلة' : 'Add to Cart'}
                </motion.button>
                <button className="p-3 bg-slate-800 rounded-lg text-slate-400 hover:text-red-400 transition-colors">
                  <Heart className="w-5 h-5" />
                </button>
              </div>

              <CouponInput />
            </motion.div>
          </div>

          {/* Tabs */}
          <div className="mt-12">
            <div className="flex gap-4 border-b border-slate-800">
              {[
                { key: 'description', label: isRTL ? 'الوصف' : 'Description' },
                { key: 'content', label: isRTL ? 'المحتوى' : 'Content' },
                { key: 'reviews', label: isRTL ? 'التقييمات' : 'Reviews' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as typeof activeTab)}
                  className={`px-6 py-3 font-medium transition-colors ${
                    activeTab === tab.key
                      ? 'text-amber-400 border-b-2 border-amber-400'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="py-8">
              {activeTab === 'description' && (
                <p className="text-slate-300 leading-relaxed">{product.description}</p>
              )}

              {activeTab === 'content' && (
                <div className="space-y-4">
                  {[ 
                    isRTL ? 'مقدمة في BIM' : 'Introduction to BIM',
                    isRTL ? 'أساسيات Revit' : 'Revit Fundamentals',
                    isRTL ? 'النمذجة المتقدمة' : 'Advanced Modeling',
                    isRTL ? 'إدارة المشاريع' : 'Project Management',
                    isRTL ? 'التصدير والتنسيق' : 'Export & Coordination',
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3 p-4 bg-slate-900/50 rounded-lg">
                      <div className="w-8 h-8 bg-amber-500/10 rounded-lg flex items-center justify-center text-amber-400 font-medium">
                        {i + 1}
                      </div>
                      <span className="text-white">{item}</span>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'reviews' && (
                <div>
                  {/* Review Form */}
                  <form onSubmit={handleSubmitReview} className="mb-8 p-6 bg-slate-900/50 rounded-xl">
                    <h3 className="text-lg font-bold text-white mb-4">{isRTL ? 'أضف تقييمك' : 'Add Your Review'}</h3>
                    <div className="flex gap-2 mb-4">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button key={star} type="button" onClick={() => setReviewRating(star)}>
                          <Star className={`w-6 h-6 ${star <= reviewRating ? 'text-amber-400 fill-amber-400' : 'text-slate-600'}`} />
                        </button>
                      ))}
                    </div>
                    <textarea
                      value={reviewText}
                      onChange={(e) => setReviewText(e.target.value)}
                      rows={3}
                      placeholder={isRTL ? 'اكتب تقييمك هنا...' : 'Write your review here...'}
                      className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 resize-none mb-4"
                    />
                    <button type="submit" className="px-6 py-2 bg-amber-500 text-slate-950 font-bold rounded-lg">
                      {isRTL ? 'إرسال' : 'Submit'}
                    </button>
                  </form>

                  {/* Reviews List */}
                  <div className="space-y-4">
                    {reviews.map((review) => (
                      <div key={review.id} className="p-4 bg-slate-900/50 rounded-xl">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full" />
                          <div>
                            <p className="text-white font-medium">{review.user}</p>
                            <div className="flex items-center gap-2">
                              <div className="flex">
                                {[...Array(5)].map((_, i) => (
                                  <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'text-amber-400 fill-amber-400' : 'text-slate-600'}`} />
                                ))}
                              </div>
                              <span className="text-slate-500 text-xs">{review.date}</span>
                            </div>
                          </div>
                        </div>
                        <p className="text-slate-300">{review.text}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ProductDetail;