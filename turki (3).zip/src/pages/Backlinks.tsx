import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { ExternalLink, Link2, Globe, Award, TrendingUp, CheckCircle } from 'lucide-react';

const Backlinks: React.FC = () => {
  const { isRTL } = useLanguage();

  const partners = [
    { name: 'LinkedIn', domain: 'linkedin.com', type: 'Professional Network', da: 98 },
    { name: 'Medium', domain: 'medium.com', type: 'Blogging Platform', da: 96 },
    { name: 'Dev.to', domain: 'dev.to', type: 'Developer Community', da: 92 },
    { name: 'Hashnode', domain: 'hashnode.dev', type: 'Tech Blogging', da: 85 },
    { name: 'Product Hunt', domain: 'producthunt.com', type: 'Product Launch', da: 91 },
    { name: 'Crunchbase', domain: 'crunchbase.com', type: 'Business Directory', da: 91 },
  ];

  const strategies = [
    { 
      title: isRTL ? 'كتابة مقالات ضيف' : 'Guest Posting',
      desc: isRTL ? 'اكتب مقالات عالية الجودة للمواقع الهندسية والمدونات التقنية' : 'Write high-quality articles for engineering websites and tech blogs'
    },
    { 
      title: isRTL ? 'إنشاء محتوى قابل للمشاركة' : 'Create Shareable Content',
      desc: isRTL ? 'أدوات مجانية، قوالب، إحصائيات تجذب الروابط الطبيعية' : 'Free tools, templates, and stats that attract natural links'
    },
    { 
      title: isRTL ? 'الشراكات الاستراتيجية' : 'Strategic Partnerships',
      desc: isRTL ? 'تعاون مع الجامعات والشركات الهندسية' : 'Partner with universities and engineering companies'
    },
    { 
      title: isRTL ? 'التواجد الاجتماعي' : 'Social Presence',
      desc: isRTL ? 'بناء حضور قوي على LinkedIn وTwitter وYouTube' : 'Build strong presence on LinkedIn, Twitter, and YouTube'
    },
  ];

  const directoryListings = [
    { name: 'Google Business Profile', status: 'active' },
    { name: 'Bing Places', status: 'active' },
    { name: 'Crunchbase', status: 'pending' },
    { name: 'Yellow Pages', status: 'active' },
    { name: 'Houzz (Engineering)', status: 'pending' },
    { name: 'LinkedIn Company', status: 'active' },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500/10 border border-amber-500/20 rounded-full text-amber-400 text-sm font-medium mb-6">
              <TrendingUp className="w-4 h-4" />
              {isRTL ? 'استراتيجية النمو' : 'Growth Strategy'}
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'استراتيجية الباك لينك' : 'Backlink Strategy'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              {isRTL 
                ? 'خطة شاملة لبناء روابط عالية الجودة لتصدر نتائج البحث'
                : 'Comprehensive plan to build high-quality links for search ranking'}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-slate-900/50 border-y border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: '50+', label: isRTL ? 'رابط خارجي' : 'External Links' },
              { value: '25+', label: isRTL ? 'مجال موثوق' : 'Trusted Domains' },
              { value: 'DA 50+', label: isRTL ? 'متوسط الدومين' : 'Avg Domain Authority' },
              { value: '100%', label: isRTL ? 'روابط طبيعية' : 'Natural Links' },
            ].map((stat, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                <div className="text-3xl font-bold text-amber-400">{stat.value}</div>
                <div className="text-slate-400 text-sm">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Strategies */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-white mb-8">{isRTL ? 'استراتيجيات بناء الروابط' : 'Link Building Strategies'}</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {strategies.map((strategy, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 hover:border-amber-500/30 transition-colors">
                <h3 className="text-lg font-bold text-white mb-2">{strategy.title}</h3>
                <p className="text-slate-400">{strategy.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Partner Sites */}
      <section className="py-16 bg-slate-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-white mb-8">{isRTL ? 'مواقع الشركاء المحتملة' : 'Potential Partner Sites'}</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {partners.map((partner, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }} className="flex items-center justify-between bg-slate-900/50 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <Globe className="w-5 h-5 text-amber-400" />
                  <div>
                    <p className="text-white font-medium">{partner.name}</p>
                    <p className="text-slate-500 text-xs">{partner.type}</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-green-400 text-sm font-medium">DA {partner.da}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Directory Listings */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-white mb-8">{isRTL ? 'قوائم الأدلة' : 'Directory Listings'}</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {directoryListings.map((dir, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }} className="flex items-center justify-between bg-slate-900/50 border border-slate-800 rounded-xl p-4">
                <span className="text-white">{dir.name}</span>
                <span className={`flex items-center gap-1 text-sm ${dir.status === 'active' ? 'text-green-400' : 'text-yellow-400'}`}>
                  {dir.status === 'active' && <CheckCircle className="w-4 h-4" />}
                  {dir.status === 'active' ? (isRTL ? 'مفعّل' : 'Active') : (isRTL ? 'قيد المراجعة' : 'Pending')}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-slate-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">{isRTL ? 'هل تريد الشراكة معنا؟' : 'Want to Partner With Us?'}</h2>
          <p className="text-slate-400 mb-8">{isRTL ? 'نرحب بالشراكات والتبادل الروابط عالية الجودة' : 'We welcome partnerships and high-quality link exchanges'}</p>
          <motion.a href="/contact" className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg" whileHover={{ scale: 1.02 }}>
            <Link2 className="w-5 h-5" />
            {isRTL ? 'تواصل معنا' : 'Contact Us'}
          </motion.a>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Backlinks;