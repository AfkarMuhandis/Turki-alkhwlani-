import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import {
  Wrench, MessageSquare, Users, PenTool,
  CheckCircle, ArrowRight, Clock, Star,
  Building2, Cpu, FileText, HardHat
} from 'lucide-react';

const Services: React.FC = () => {
  const { isRTL } = useLanguage();

  const mainServices = [
    {
      icon: Wrench,
      title: isRTL ? 'الخدمات الهندسية' : 'Engineering Services',
      subtitle: isRTL ? 'حلول هندسية شاملة' : 'Comprehensive Engineering Solutions',
      color: 'from-amber-500 to-orange-500',
      features: [
        isRTL ? 'تصميم المباني والمنشآت' : 'Building & Structure Design',
        isRTL ? 'دراسات الجدوى' : 'Feasibility Studies',
        isRTL ? 'إدارة المشاريع' : 'Project Management',
        isRTL ? 'الإشراف على التنفيذ' : 'Construction Supervision',
        isRTL ? 'فحص الجودة' : 'Quality Inspection',
      ],
      price: isRTL ? 'يبدأ من 5,000 ر.س' : 'Starting from 1,333 USD',
    },
    {
      icon: MessageSquare,
      title: isRTL ? 'الاستشارات الفنية' : 'Technical Consulting',
      subtitle: isRTL ? 'خبرة وتوجيه احترافي' : 'Professional Guidance & Expertise',
      color: 'from-blue-500 to-cyan-500',
      features: [
        isRTL ? 'استشارات هندسية متخصصة' : 'Specialized Engineering Consultation',
        isRTL ? 'تقييم المشاريع' : 'Project Evaluation',
        isRTL ? 'حل المشكلات التقنية' : 'Technical Problem Solving',
        isRTL ? 'دعم فني مستمر' : 'Ongoing Technical Support',
        isRTL ? 'مراجعة التصاميم' : 'Design Review',
      ],
      price: isRTL ? 'يبدأ من 300 ر.س/ساعة' : 'Starting from 80 USD/hour',
    },
    {
      icon: Users,
      title: isRTL ? 'التدريب والتأهيل' : 'Training & Development',
      subtitle: isRTL ? 'برامج تدريبية متقدمة' : 'Advanced Training Programs',
      color: 'from-purple-500 to-pink-500',
      features: [
        isRTL ? 'دورات مهندسين محترفين' : 'Professional Engineer Courses',
        isRTL ? 'ورش عمل عملية' : 'Practical Workshops',
        isRTL ? 'شهادات معتمدة' : 'Certified Certificates',
        isRTL ? 'تدريب على البرمجيات' : 'Software Training',
        isRTL ? 'تطوير المهارات القيادية' : 'Leadership Skills Development',
      ],
      price: isRTL ? 'يبدأ من 1,000 ر.س' : 'Starting from 267 USD',
    },
    {
      icon: PenTool,
      title: isRTL ? 'التصميم الهندسي' : 'Engineering Design',
      subtitle: isRTL ? 'تصاميم مبتكرة ودقيقة' : 'Innovate & Precise Designs',
      color: 'from-green-500 to-emerald-500',
      features: [
        isRTL ? 'تصميم معماري' : 'Architectural Design',
        isRTL ? 'تصميم إنشائي' : 'Structural Design',
        isRTL ? 'تصميم MEP' : 'MEP Design',
        isRTL ? 'نماذج BIM ثلاثية الأبعاد' : '3D BIM Modeling',
        isRTL ? 'رسومات تنفيذية' : 'Construction Drawings',
      ],
      price: isRTL ? 'يبدأ من 3,000 ر.س' : 'Starting from 800 USD',
    },
  ];

  const additionalServices = [
    { icon: Cpu, title: isRTL ? 'الحلول الرقمية' : 'Digital Solutions', desc: isRTL ? 'تحويل رقمي وأتمتة' : 'Digital transformation & automation' },
    { icon: Building2, title: isRTL ? 'إدارة المرافق' : 'Facility Management', desc: isRTL ? 'تشغيل وصيانة' : 'Operations & maintenance' },
    { icon: FileText, title: isRTL ? 'الوثائق والتقارير' : 'Documentation & Reports', desc: isRTL ? 'تقارير فنية شاملة' : 'Comprehensive technical reports' },
    { icon: HardHat, title: isRTL ? 'السلامة والصحة' : 'Safety & Health', desc: isRTL ? 'معايير السلامة' : 'Safety standards compliance' },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'خدماتنا' : 'Our Services'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              {isRTL 
                ? 'نقدم مجموعة شاملة من الخدمات الهندسية الاحترافية التي تلبي جميع احتياجاتك'
                : 'We offer a comprehensive range of professional engineering services that meet all your needs'}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Main Services Grid */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            {mainServices.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15 }}
                className="group relative bg-slate-900/50 border border-slate-800 rounded-2xl p-8 hover:border-amber-500/30 transition-all overflow-hidden"
              >
                {/* Background Glow */}
                <div className={`absolute top-0 right-0 w-64 h-64 bg-gradient-to-br ${service.color} opacity-5 rounded-full blur-3xl group-hover:opacity-10 transition-opacity`} />
                
                <div className="relative">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        <service.icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-2">{service.title}</h3>
                      <p className="text-slate-400">{service.subtitle}</p>
                    </div>
                    <div className="bg-slate-800/50 rounded-lg px-4 py-2">
                      <span className="text-amber-400 font-medium text-sm">{service.price}</span>
                    </div>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-3 text-slate-300">
                        <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <motion.a
                    href="/bookings"
                    className={`inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r ${service.color} text-white font-bold rounded-lg shadow-lg hover:shadow-xl transition-shadow`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {isRTL ? 'اطلب الخدمة' : 'Request Service'}
                    <ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                  </motion.a>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-24 bg-slate-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              {isRTL ? 'خدمات إضافية' : 'Additional Services'}
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              {isRTL ? 'خدمات مكملة لتغطية جميع احتياجاتك' : 'Complementary services to cover all your needs'}
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {additionalServices.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 hover:border-amber-500/20 transition-colors group"
              >
                <div className="w-12 h-12 bg-amber-500/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-amber-500/20 transition-colors">
                  <service.icon className="w-6 h-6 text-amber-400" />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{service.title}</h3>
                <p className="text-slate-400 text-sm">{service.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              {isRTL ? 'كيف نعمل' : 'How We Work'}
            </h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              {isRTL ? 'خطوات بسيطة وواضحة لتحقيق أهدافك' : 'Simple and clear steps to achieve your goals'}
            </p>
          </motion.div>

          <div className="grid md:grid-cols-4 gap-6">
            {[ 
              { step: '01', title: isRTL ? 'الاستشارة' : 'Consultation', desc: isRTL ? 'نفهم احتياجاتك ومتطلباتك' : 'We understand your needs and requirements' },
              { step: '02', title: isRTL ? 'التخطيط' : 'Planning', desc: isRTL ? 'نضع خطة عمل مفصلة' : 'We create a detailed action plan' },
              { step: '03', title: isRTL ? 'التنفيذ' : 'Execution', desc: isRTL ? 'نفذ الخطة بأعلى جودة' : 'Execute the plan with highest quality' },
              { step: '04', title: isRTL ? 'التسليم' : 'Delivery', desc: isRTL ? 'نسلم المشروع في الوقت المحدد' : 'Deliver the project on time' },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative text-center"
              >
                <div className="text-6xl font-black text-amber-500/10 mb-4">{item.step}</div>
                <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                <p className="text-slate-400 text-sm">{item.desc}</p>
                {index < 3 && (
                  <ArrowRight className={`hidden md:block absolute -right-3 top-10 w-6 h-6 text-amber-500/30 ${isRTL ? '' : 'rotate-180'}`} />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-slate-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-gradient-to-r from-amber-500/20 to-amber-600/10 border border-amber-500/30 rounded-3xl p-8 sm:p-12 text-center"
          >
            <h2 className="text-3xl font-bold text-white mb-4">
              {isRTL ? 'هل تحتاج خدمة مخصصة؟' : 'Need a Custom Service?'}
            </h2>
            <p className="text-slate-300 mb-8 max-w-xl mx-auto">
              {isRTL ? 'تواصل معنا وسنساعدك في اختيار الخدمة المناسبة لمشروعك' : 'Contact us and we will help you choose the right service for your project'}
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <motion.a href="/contact" className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg shadow-lg" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                {isRTL ? 'تواصل معنا' : 'Contact Us'}
                <ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
              </motion.a>
              <motion.a href="/bookings" className="inline-flex items-center gap-2 px-8 py-4 bg-slate-800/50 border border-slate-700 text-white font-medium rounded-lg hover:border-amber-500/50" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                <Clock className="w-5 h-5" />
                {isRTL ? 'احجز موعد' : 'Book Appointment'}
              </motion.a>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Services;