import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { 
  MapPin, Calendar, ArrowRight, Search,
  Filter, Building2, Home, Factory, Car
} from 'lucide-react';

const Projects: React.FC = () => {
  const { isRTL } = useLanguage();
  const [activeFilter, setActiveFilter] = useState('all');

  const categories = [
    { key: 'all', label: isRTL ? 'الكل' : 'All' },
    { key: 'residential', label: isRTL ? 'سكني' : 'Residential' },
    { key: 'commercial', label: isRTL ? 'تجاري' : 'Commercial' },
    { key: 'industrial', label: isRTL ? 'صناعي' : 'Industrial' },
    { key: 'infrastructure', label: isRTL ? 'بنية تحتية' : 'Infrastructure' },
  ];

  const projects = [
    {
      id: 1,
      title: isRTL ? 'برج الأفق السكني' : 'Horizon Residential Tower',
      category: 'residential',
      location: isRTL ? 'الرياض، السعودية' : 'Riyadh, Saudi Arabia',
      year: '2023',
      area: isRTL ? '45,000 م²' : '45,000 m²',
      image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800',
      description: isRTL ? 'برج سكني فاخر من 40 طابق مع تصميم عصري' : 'Luxury residential tower with 40 floors and modern design'
    },
    {
      id: 2,
      title: isRTL ? 'مجمع الأعمال التجاري' : 'Business Complex Commercial',
      category: 'commercial',
      location: isRTL ? 'جدة، السعودية' : 'Jeddah, Saudi Arabia',
      year: '2023',
      area: isRTL ? '78,000 م²' : '78,000 m²',
      image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800',
      description: isRTL ? 'مجمع تجاري متكامل بمكاتب ومساحات تجارية' : 'Integrated commercial complex with offices and retail spaces'
    },
    {
      id: 3,
      title: isRTL ? 'المصنع الذكي' : 'Smart Factory',
      category: 'industrial',
      location: isRTL ? 'الدمام، السعودية' : 'Dammam, Saudi Arabia',
      year: '2022',
      area: isRTL ? '120,000 م²' : '120,000 m²',
      image: 'https://images.unsplash.com/photo-1565610222536-ef125c59da2e?w=800',
      description: isRTL ? 'مصنع ذكي بتقنيات الصناعة 4.0' : 'Smart factory with Industry 4.0 technologies'
    },
    {
      id: 4,
      title: isRTL ? 'فيلا الواحة الفاخرة' : 'Oasis Luxury Villa',
      category: 'residential',
      location: isRTL ? 'الخبر، السعودية' : 'Khobar, Saudi Arabia',
      year: '2023',
      area: isRTL ? '2,500 م²' : '2,500 m²',
      image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800',
      description: isRTL ? 'فيلا فاخرة بتصميم حديث وحديقة واسعة' : 'Luxury villa with modern design and spacious garden'
    },
    {
      id: 5,
      title: isRTL ? 'محطة الطاقة الشمسية' : 'Solar Power Station',
      category: 'infrastructure',
      location: isRTL ? 'تبوك، السعودية' : 'Tabuk, Saudi Arabia',
      year: '2022',
      area: isRTL ? '500,000 م²' : '500,000 m²',
      image: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800',
      description: isRTL ? 'محطة طاقة شمسية بسعة 500 ميغاواط' : 'Solar power station with 500 MW capacity'
    },
    {
      id: 6,
      title: isRTL ? 'المركز التقني المتقدم' : 'Advanced Tech Center',
      category: 'commercial',
      location: isRTL ? 'الرياض، السعودية' : 'Riyadh, Saudi Arabia',
      year: '2023',
      area: isRTL ? '35,000 م²' : '35,000 m²',
      image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800',
      description: isRTL ? 'مركز تقني متطور لشركات التكنولوجيا' : 'State-of-the-art tech center for technology companies'
    },
  ];

  const filteredProjects = activeFilter === 'all' 
    ? projects 
    : projects.filter(p => p.category === activeFilter);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'residential': return Home;
      case 'commercial': return Building2;
      case 'industrial': return Factory;
      case 'infrastructure': return Car;
      default: return Building2;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'مشاريعنا' : 'Our Projects'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              {isRTL 
                ? 'نفتخر بمجموعة متنوعة من المشاريع الناجحة التي أنجزناها'
                : 'We are proud of our diverse portfolio of successful projects'}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter & Projects Grid */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Filter Buttons */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map((cat) => (
              <button
                key={cat.key}
                onClick={() => setActiveFilter(cat.key)}
                className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
                  activeFilter === cat.key
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/25'
                    : 'bg-slate-800/50 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </motion.div>

          {/* Projects Grid */}
          <motion.div layout className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project) => {
              const CategoryIcon = getCategoryIcon(project.category);
              return (
                <motion.article
                  key={project.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                  className="group bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden hover:border-amber-500/30 transition-all"
                >
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                    
                    {/* Category Badge */}
                    <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 bg-slate-900/80 backdrop-blur-sm rounded-full">
                      <CategoryIcon className="w-4 h-4 text-amber-400" />
                      <span className="text-white text-sm font-medium">
                        {categories.find(c => c.key === project.category)?.label}
                      </span>
                    </div>
                  </div>

                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-slate-400 text-sm mb-4 line-clamp-2">{project.description}</p>
                    
                    <div className="flex items-center justify-between text-sm text-slate-500">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        <span>{project.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        <span>{project.year}</span>
                      </div>
                    </div>
                    
                    <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between">
                      <span className="text-amber-400 font-medium text-sm">{project.area}</span>
                      <motion.a href="#" className="flex items-center gap-1 text-white hover:text-amber-400 transition-colors" whileHover={{ x: isRTL ? -5 : 5 }}>
                        <span className="text-sm font-medium">{isRTL ? 'التفاصيل' : 'Details'}</span>
                        <ArrowRight className={`w-4 h-4 ${isRTL ? '' : 'rotate-180'}`} />
                      </motion.a>
                    </div>
                  </div>
                </motion.article>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-slate-900/50 border-y border-amber-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[ 
              { value: '500+', label: isRTL ? 'مشروع منجز' : 'Completed Projects' },
              { value: '15+', label: isRTL ? 'دولة' : 'Countries' },
              { value: '98%', label: isRTL ? 'نسبة النجاح' : 'Success Rate' },
              { value: '24/7', label: isRTL ? 'دعم فني' : 'Technical Support' },
            ].map((stat, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}>
                <div className="text-4xl font-bold text-amber-400 mb-2">{stat.value}</div>
                <div className="text-slate-400">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Projects;