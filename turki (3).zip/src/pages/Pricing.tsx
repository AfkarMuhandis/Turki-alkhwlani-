import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Check, X, ArrowRight, Zap, Building2, Crown } from 'lucide-react';

const Pricing: React.FC = () => {
  const { isRTL } = useLanguage();
  const [annual, setAnnual] = useState(true);

  const plans = [
    {
      name: isRTL ? 'المبتدئ' : 'Starter',
      nameEn: 'Starter',
      icon: Zap,
      price: annual ? 0 : 0,
      period: isRTL ? 'مجاناً' : 'Free',
      description: isRTL ? 'للمهندسين المبتدئين' : 'For beginner engineers',
      features: [
        { text: isRTL ? 'استشارة واحدة شهرياً' : '1 consultation/month', included: true },
        { text: isRTL ? 'الوصول للمدونة' : 'Blog access', included: true },
        { text: isRTL ? 'أدوات أساسية' : 'Basic tools', included: true },
        { text: isRTL ? 'دعم المجتمع' : 'Community support', included: true },
        { text: isRTL ? 'شهادات معتمدة' : 'Certified certificates', included: false },
        { text: isRTL ? 'دعم فني مباشر' : 'Direct technical support', included: false },
      ],
      cta: isRTL ? 'ابدأ مجاناً' : 'Start Free',
      popular: false,
    },
    {
      name: isRTL ? 'المحترف' : 'Professional',
      nameEn: 'Professional',
      icon: Building2,
      price: annual ? 99 : 129,
      period: isRTL ? 'دولار/شهرياً' : '$/month',
      description: isRTL ? 'للمهندسين المحترفين' : 'For professional engineers',
      features: [
        { text: isRTL ? 'استشارات غير محدودة' : 'Unlimited consultations', included: true },
        { text: isRTL ? 'الوصول الكامل للمحتوى' : 'Full content access', included: true },
        { text: isRTL ? 'جميع الأدوات المتقدمة' : 'All advanced tools', included: true },
        { text: isRTL ? 'دعم فني 24/7' : '24/7 technical support', included: true },
        { text: isRTL ? 'شهادات معتمدة' : 'Certified certificates', included: true },
        { text: isRTL ? 'خصم 20% على الدورات' : '20% off courses', included: true },
      ],
      cta: isRTL ? 'ابدأ الآن' : 'Get Started',
      popular: true,
    },
    {
      name: isRTL ? 'المؤسسي' : 'Enterprise',
      nameEn: 'Enterprise',
      icon: Crown,
      price: annual ? 299 : 399,
      period: isRTL ? 'دولار/شهرياً' : '$/month',
      description: isRTL ? 'للشركات والفرق' : 'For companies and teams',
      features: [
        { text: isRTL ? 'كل مميزات المحترف' : 'All Professional features', included: true },
        { text: isRTL ? 'حسابات متعددة' : 'Multiple accounts', included: true },
        { text: isRTL ? 'API مخصص' : 'Custom API', included: true },
        { text: isRTL ? 'تقارير مخصصة' : 'Custom reports', included: true },
        { text: isRTL ? 'مدير حساب مخصص' : 'Dedicated account manager', included: true },
        { text: isRTL ? 'تدريب مخصص' : 'Custom training', included: true },
      ],
      cta: isRTL ? 'تواصل معنا' : 'Contact Us',
      popular: false,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'الأسعار' : 'Pricing'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed mb-10">
              {isRTL 
                ? 'اختر الخطة المناسبة لاحتياجاتك الهندسية'
                : 'Choose the right plan for your engineering needs'}
            </p>

            {/* Toggle */}
            <div className="inline-flex items-center gap-4 bg-slate-900/50 border border-slate-800 rounded-full p-1">
              <button
                onClick={() => setAnnual(true)}
                className={`px-6 py-2 rounded-full font-medium transition-all ${annual ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950' : 'text-slate-400 hover:text-white'}`}
              >
                {isRTL ? 'سنوي (وفر 20%)' : 'Annual (Save 20%)'}
              </button>
              <button
                onClick={() => setAnnual(false)}
                className={`px-6 py-2 rounded-full font-medium transition-all ${!annual ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950' : 'text-slate-400 hover:text-white'}`}
              >
                {isRTL ? 'شهري' : 'Monthly'}
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.15 }}
                className={`relative bg-slate-900/50 border rounded-2xl p-8 ${plan.popular ? 'border-amber-500' : 'border-slate-800'} hover:border-amber-500/50 transition-colors`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="px-4 py-1 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 text-sm font-bold rounded-full">
                      {isRTL ? 'الأكثر شعبية' : 'Most Popular'}
                    </span>
                  </div>
                )}

                <div className="text-center mb-6">
                  <div className={`w-14 h-14 ${plan.popular ? 'bg-gradient-to-br from-amber-400 to-amber-600' : 'bg-slate-800'} rounded-xl flex items-center justify-center mx-auto mb-4`}>
                    <plan.icon className={`w-7 h-7 ${plan.popular ? 'text-slate-950' : 'text-amber-400'}`} />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                  <p className="text-slate-400 text-sm">{plan.description}</p>
                </div>

                <div className="text-center mb-6">
                  <span className="text-4xl font-bold text-white">${plan.price}</span>
                  <span className="text-slate-400 ml-2">{plan.period}</span>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-3">
                      {feature.included ? (
                        <div className="w-5 h-5 bg-green-500/10 rounded-full flex items-center justify-center">
                          <Check className="w-3 h-3 text-green-400" />
                        </div>
                      ) : (
                        <div className="w-5 h-5 bg-slate-800 rounded-full flex items-center justify-center">
                          <X className="w-3 h-3 text-slate-500" />
                        </div>
                      )}
                      <span className={feature.included ? 'text-slate-300' : 'text-slate-500'}>{feature.text}</span>
                    </li>
                  ))}
                </ul>

                <motion.a
                  href={plan.price === 0 ? '/register' : '/bookings'}
                  className={`block text-center py-3 rounded-xl font-bold transition-all ${plan.popular ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/25' : 'bg-slate-800 text-white hover:bg-slate-700'}`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {plan.cta}
                </motion.a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 bg-slate-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-white text-center mb-12">{isRTL ? 'أسئلة شائعة' : 'Frequently Asked Questions'}</h2>
          <div className="space-y-4">
            {[ 
              { q: isRTL ? 'هل يمكنني تغيير الخطة لاحقاً؟' : 'Can I change my plan later?', a: isRTL ? 'نعم، يمكنك الترقية أو إلغاء خطتك في أي وقت.' : 'Yes, you can upgrade or cancel your plan at any time.' },
              { q: isRTL ? 'هل هناك فترة تجريبية؟' : 'Is there a free trial?', a: isRTL ? 'نعم، نقدم فترة تجريبية مجانية 14 يوم للخطة المحترفة.' : 'Yes, we offer a 14-day free trial for the Professional plan.' },
              { q: isRTL ? 'ما هي طرق الدفع المتاحة؟' : 'What payment methods are available?', a: isRTL ? 'نقبل بطاقات الائتمان وPayPal والتحويل البنكي.' : 'We accept credit cards, PayPal, and bank transfers.' },
              { q: isRTL ? 'هل يمكنني الحصول على استرداد؟' : 'Can I get a refund?', a: isRTL ? 'نعم، نقدم ضمان استرداد 30 يوم.' : 'Yes, we offer a 30-day money-back guarantee.' },
            ].map((faq, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
                <h3 className="text-white font-medium mb-2">{faq.q}</h3>
                <p className="text-slate-400 text-sm">{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">{isRTL ? 'هل لديك أسئلة؟' : 'Have Questions?'}</h2>
          <p className="text-slate-400 mb-8">{isRTL ? 'تواصل معنا وسنساعدك في اختيار الخطة المناسبة' : 'Contact us and we\'ll help you choose the right plan'}</p>
          <motion.a href="/contact" className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg" whileHover={{ scale: 1.02 }}>
            {isRTL ? 'تواصل معنا' : 'Contact Us'}<ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.a>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Pricing;