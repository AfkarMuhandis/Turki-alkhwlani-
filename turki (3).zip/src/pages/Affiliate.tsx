import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { ExternalLink, Star, TrendingUp, Users, DollarSign, ArrowRight } from 'lucide-react';

const Affiliate: React.FC = () => {
  const { isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { key: 'all', label: isRTL ? 'الكل' : 'All' },
    { key: 'hosting', label: isRTL ? 'استضافة' : 'Hosting' },
    { key: 'ai', label: isRTL ? 'ذكاء اصطناعي' : 'AI Tools' },
    { key: 'software', label: isRTL ? 'برمجيات' : 'Software' },
    { key: 'courses', label: isRTL ? 'دورات' : 'Courses' },
    { key: 'productivity', label: isRTL ? 'إنتاجية' : 'Productivity' },
  ];

  const affiliateProducts = [
    {
      id: '1',
      name: isRTL ? 'Hostinger' : 'Hostinger',
      nameEn: 'Hostinger',
      description: isRTL ? 'استضافة ويب سريعة وآمنة بأسعار منافسة' : 'Fast and secure web hosting at competitive prices',
      logo: 'https://images.unsplash.com/photo-1544197150-b99a580bb7a1?w=200',
      category: 'hosting',
      rating: 4.8,
      commission: '20%',
      features: [isRTL ? 'سرعة فائقة' : 'Ultra-fast', isRTL ? 'دعم 24/7' : '24/7 Support', isRTL ? 'ضمان 30 يوم' : '30-day guarantee'],
      pros: [isRTL ? 'أسعار ممتازة' : 'Great prices', isRTL ? 'سهولة الاستخدام' : 'Easy to use'],
      cons: [isRTL ? 'دعم محدود في الخطة المجانية' : 'Limited free plan support'],
      url: '#',
    },
    {
      id: '2',
      name: isRTL ? 'ChatGPT Plus' : 'ChatGPT Plus',
      nameEn: 'ChatGPT Plus',
      description: isRTL ? 'أداة الذكاء الاصطناعي الأكثر تقدماً للمحادثات' : 'The most advanced AI conversation tool',
      logo: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=200',
      category: 'ai',
      rating: 4.9,
      commission: '15%',
      features: [isRTL ? 'GPT-4' : 'GPT-4', isRTL ? 'سرعة فائقة' : 'Ultra-fast', isRTL ? 'وصول مبكر' : 'Early access'],
      pros: [isRTL ? 'ذكاء عالي' : 'High intelligence', isRTL ? 'متعدد الاستخدامات' : 'Versatile'],
      cons: [isRTL ? 'اشتراك شهري' : 'Monthly subscription'],
      url: '#',
    },
    {
      id: '3',
      name: isRTL ? 'AutoCAD' : 'AutoCAD',
      nameEn: 'AutoCAD',
      description: isRTL ? 'برنامج التصميم الهندسي الأكثر استخداماً في العالم' : 'The most widely used engineering design software',
      logo: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=200',
      category: 'software',
      rating: 4.7,
      commission: '10%',
      features: [isRTL ? 'تصميم 2D/3D' : '2D/3D Design', isRTL ? 'أدوات متقدمة' : 'Advanced tools', isRTL ? 'تكامل BIM' : 'BIM integration'],
      pros: [isRTL ? 'معيار الصناعة' : 'Industry standard', isRTL ? 'أدوات شاملة' : 'Comprehensive tools'],
      cons: [isRTL ? 'سعر مرتفع' : 'High price', isRTL ? 'يتطلب تدريب' : 'Requires training'],
      url: '#',
    },
    {
      id: '4',
      name: isRTL ? 'Udemy' : 'Udemy',
      nameEn: 'Udemy',
      description: isRTL ? 'منصة الدورات التعليمية الأكبر في العالم' : 'The world largest online learning platform',
      logo: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=200',
      category: 'courses',
      rating: 4.6,
      commission: '25%',
      features: [isRTL ? 'آلاف الدورات' : 'Thousands of courses', isRTL ? 'شهادات' : 'Certificates', isRTL ? 'وصول مدى الحياة' : 'Lifetime access'],
      pros: [isRTL ? 'تنوع كبير' : 'Great variety', isRTL ? 'أسعار منخفضة' : 'Low prices'],
      cons: [isRTL ? 'جودة متفاوتة' : 'Varying quality'],
      url: '#',
    },
    {
      id: '5',
      name: isRTL ? 'Notion' : 'Notion',
      nameEn: 'Notion',
      description: isRTL ? 'أداة إنتاجية شاملة للتنظيم والتوثيق' : 'All-in-one productivity tool for organization and documentation',
      logo: 'https://images.unsplash.com/photo-1517842646443-13e2eb7b6871?w=200',
      category: 'productivity',
      rating: 4.8,
      commission: '15%',
      features: [isRTL ? 'ملاحظات' : 'Notes', isRTL ? 'قواعد بيانات' : 'Databases', isRTL ? 'تعاون' : 'Collaboration'],
      pros: [isRTL ? 'مرونة عالية' : 'Highly flexible', isRTL ? 'مجاني للبداية' : 'Free to start'],
      cons: [isRTL ? 'منحنى تعلم' : 'Learning curve'],
      url: '#',
    },
    {
      id: '6',
      name: isRTL ? 'Midjourney' : 'Midjourney',
      nameEn: 'Midjourney',
      description: isRTL ? 'أداة توليد الصور بالذكاء الاصطناعي' : 'AI-powered image generation tool',
      logo: 'https://images.unsplash.com/photo-1676299085793-197946aba8f7?w=200',
      category: 'ai',
      rating: 4.7,
      commission: '12%',
      features: [isRTL ? 'جودة عالية' : 'High quality', isRTL ? 'سرعة' : 'Speed', isRTL ? 'تنوع' : 'Variety'],
      pros: [isRTL ? 'نتائج مذهلة' : 'Amazing results', isRTL ? 'سهل الاستخدام' : 'Easy to use'],
      cons: [isRTL ? 'يحتاج Discord' : 'Needs Discord'],
      url: '#',
    },
  ];

  const filteredProducts = activeCategory === 'all' 
    ? affiliateProducts 
    : affiliateProducts.filter(p => p.category === activeCategory);

  const stats = [
    { value: '50+', label: isRTL ? 'شريك' : 'Partners', icon: Users },
    { value: '25%', label: isRTL ? 'عمولة قصوى' : 'Max Commission', icon: TrendingUp },
    { value: '$10K+', label: isRTL ? 'أرباح شهرية' : 'Monthly Earnings', icon: DollarSign },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'برنامج الأفلييت' : 'Affiliate Program'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed mb-10">
              {isRTL 
                ? 'اكتشف أفضل الأدوات والخدمات الهندسية واحصل على عمولة على كل عملية شراء'
                : 'Discover the best engineering tools and services and earn commission on every purchase'}
            </p>

            {/* Stats */}
            <div className="flex flex-wrap justify-center gap-8">
              {stats.map((stat, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="text-center">
                  <div className="flex items-center justify-center w-12 h-12 bg-amber-500/10 rounded-xl mx-auto mb-2">
                    <stat.icon className="w-6 h-6 text-amber-400" />
                  </div>
                  <div className="text-2xl font-bold text-white">{stat.value}</div>
                  <div className="text-slate-400 text-sm">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((cat) => (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
                  activeCategory === cat.key
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg'
                    : 'bg-slate-800/50 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden hover:border-amber-500/30 transition-all"
              >
                <div className="p-6">
                  {/* Header */}
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 bg-slate-800 rounded-xl flex items-center justify-center flex-shrink-0 overflow-hidden">
                      <img src={product.logo} alt={product.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white mb-1">{product.name}</h3>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                          <span className="text-white text-sm">{product.rating}</span>
                        </div>
                        <span className="text-slate-500 text-sm">|</span>
                        <span className="text-green-400 text-sm font-medium">{product.commission} {isRTL ? 'عمولة' : 'commission'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-slate-400 text-sm mb-4">{product.description}</p>

                  {/* Features */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {product.features.map((feature, i) => (
                      <span key={i} className="px-2 py-1 bg-slate-800 text-slate-300 text-xs rounded-lg">{feature}</span>
                    ))}
                  </div>

                  {/* Pros & Cons */}
                  <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                    <div>
                      <p className="text-green-400 font-medium mb-1">{isRTL ? 'المميزات' : 'Pros'}</p>
                      {product.pros.map((pro, i) => (
                        <p key={i} className="text-slate-400 text-xs">+ {pro}</p>
                      ))}
                    </div>
                    <div>
                      <p className="text-red-400 font-medium mb-1">{isRTL ? 'العيوب' : 'Cons'}</p>
                      {product.cons.map((con, i) => (
                        <p key={i} className="text-slate-400 text-xs">- {con}</p>
                      ))}
                    </div>
                  </div>

                  {/* CTA */}
                  <motion.a
                    href={product.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    {isRTL ? 'احصل على العرض' : 'Get This Deal'}
                    <ExternalLink className="w-4 h-4" />
                  </motion.a>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Join CTA */}
      <section className="py-16 bg-slate-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">{isRTL ? 'انضم لبرنامج الشراكة' : 'Join Our Affiliate Program'}</h2>
          <p className="text-slate-400 mb-8">{isRTL ? 'كن شريكاً واحصل على عمولة على كل عملية شراء من خلال رابطك' : 'Become a partner and earn commission on every purchase through your link'}</p>
          <motion.a href="/contact" className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg" whileHover={{ scale: 1.02 }}>
            {isRTL ? 'تواصل معنا' : 'Contact Us'}<ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
          </motion.a>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Affiliate;