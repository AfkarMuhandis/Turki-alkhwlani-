import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { CreditCard, Wallet, Lock, CheckCircle, ArrowRight, ShoppingBag } from 'lucide-react';

const Checkout: React.FC = () => {
  const { isRTL } = useLanguage();
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal'>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [cardData, setCardData] = useState({
    number: '',
    name: '',
    expiry: '',
    cvv: ''
  });

  // Mock cart items
  const cartItems = [
    { id: 1, name: isRTL ? 'دورة BIM المتقدمة' : 'Advanced BIM Course', price: 499 },
    { id: 2, name: isRTL ? 'قوالب AutoCAD احترافية' : 'Professional AutoCAD Templates', price: 149 },
  ];

  const subtotal = cartItems.reduce((sum, item) => sum + item.price, 0);
  const tax = subtotal * 0.05;
  const total = subtotal + tax;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    setTimeout(() => {
      setIsProcessing(false);
      setIsComplete(true);
    }, 2000);
  };

  if (isComplete) {
    return (
      <div className="min-h-screen bg-slate-950">
        <Header />
        <section className="pt-32 pb-20 flex items-center justify-center min-h-[80vh]">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 0 }} className="text-center max-w-md mx-auto px-4">
            <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">{isRTL ? 'تم الدفع بنجاح!' : 'Payment Successful!'}</h2>
            <p className="text-slate-400 mb-4">
              {isRTL 
                ? 'شكراً لك! سيتم إرسال رابط التحميل إلى بريدك الإلكتروني.'
                : 'Thank you! The download link will be sent to your email.'}
            </p>
            <p className="text-amber-400 font-mono mb-8">#{Math.random().toString(36).substring(2, 10).toUpperCase()}</p>
            <motion.a href="/store" className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg" whileHover={{ scale: 1.02 }}>
              {isRTL ? 'العودة للمتجر' : 'Back to Store'}<ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
            </motion.a>
          </motion.div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="pt-32 pb-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-3xl font-bold text-white mb-8">
            {isRTL ? 'إتمام الشراء' : 'Checkout'}
          </motion.h1>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Payment Form */}
            <div className="lg:col-span-2">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6">
                <h2 className="text-xl font-bold text-white mb-6">{isRTL ? 'طريقة الدفع' : 'Payment Method'}</h2>

                {/* Payment Method Selection */}
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <button
                    onClick={() => setPaymentMethod('card')}
                    className={`flex items-center justify-center gap-3 p-4 rounded-xl border transition-all ${paymentMethod === 'card' ? 'border-amber-500 bg-amber-500/10' : 'border-slate-700 hover:border-slate-600'}`}
                  >
                    <CreditCard className={`w-6 h-6 ${paymentMethod === 'card' ? 'text-amber-400' : 'text-slate-400'}`} />
                    <span className={paymentMethod === 'card' ? 'text-white font-medium' : 'text-slate-400'}>{isRTL ? 'بطاقة ائتمان' : 'Credit Card'}</span>
                  </button>
                  <button
                    onClick={() => setPaymentMethod('paypal')}
                    className={`flex items-center justify-center gap-3 p-4 rounded-xl border transition-all ${paymentMethod === 'paypal' ? 'border-amber-500 bg-amber-500/10' : 'border-slate-700 hover:border-slate-600'}`}
                  >
                    <Wallet className={`w-6 h-6 ${paymentMethod === 'paypal' ? 'text-amber-400' : 'text-slate-400'}`} />
                    <span className={paymentMethod === 'paypal' ? 'text-white font-medium' : 'text-slate-400'}>PayPal</span>
                  </button>
                </div>

                {/* Card Form */}
                {paymentMethod === 'card' && (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'رقم البطاقة' : 'Card Number'}</label>
                      <input
                        type="text"
                        required
                        value={cardData.number}
                        onChange={(e) => setCardData({...cardData, number: e.target.value})}
                        placeholder="1234 5678 9012 3456"
                        className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'اسم حامل البطاقة' : 'Cardholder Name'}</label>
                      <input
                        type="text"
                        required
                        value={cardData.name}
                        onChange={(e) => setCardData({...cardData, name: e.target.value})}
                        placeholder={isRTL ? 'الاسم كما يظهر على البطاقة' : 'Name as shown on card'}
                        className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'تاريخ الانتهاء' : 'Expiry Date'}</label>
                        <input
                          type="text"
                          required
                          value={cardData.expiry}
                          onChange={(e) => setCardData({...cardData, expiry: e.target.value})}
                          placeholder="MM/YY"
                          className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-300 mb-2">CVV</label>
                        <input
                          type="text"
                          required
                          value={cardData.cvv}
                          onChange={(e) => setCardData({...cardData, cvv: e.target.value})}
                          placeholder="123"
                          className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-slate-400 text-sm mt-4">
                      <Lock className="w-4 h-4" />
                      <span>{isRTL ? 'بياناتك محمية بتشفير SSL' : 'Your data is protected with SSL encryption'}</span>
                    </div>

                    <motion.button
                      type="submit"
                      disabled={isProcessing}
                      className="w-full flex items-center justify-center gap-2 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-xl mt-4"
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                    >
                      {isProcessing 
                        ? (isRTL ? 'جاري المعالجة...' : 'Processing...')
                        : (isRTL ? `ادفع ${total.toFixed(2)}$` : `Pay $${total.toFixed(2)}`)}
                    </motion.button>
                  </form>
                )}

                {/* PayPal */}
                {paymentMethod === 'paypal' && (
                  <div className="text-center py-8">
                    <p className="text-slate-400 mb-6">{isRTL ? 'سيتم توجيهك إلى PayPal لإتمام الدفع' : 'You will be redirected to PayPal to complete payment'}</p>
                    <motion.button
                      onClick={handleSubmit}
                      disabled={isProcessing}
                      className="inline-flex items-center gap-2 px-8 py-4 bg-[#0070ba] text-white font-bold rounded-xl"
                      whileHover={{ scale: 1.01 }}
                      whileTap={{ scale: 0.99 }}
                    >
                      <Wallet className="w-5 h-5" />
                      {isProcessing 
                        ? (isRTL ? 'جاري المعالجة...' : 'Processing...')
                        : (isRTL ? 'الدفع عبر PayPal' : 'Pay with PayPal')}
                    </motion.button>
                  </div>
                )}
              </motion.div>
            </div>

            {/* Order Summary */}
            <div>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 sticky top-24">
                <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-amber-400" />
                  {isRTL ? 'ملخص الطلب' : 'Order Summary'}
                </h2>

                <div className="space-y-4 mb-6">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex justify-between">
                      <span className="text-slate-300">{item.name}</span>
                      <span className="text-white font-medium">${item.price}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-slate-700 pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">{isRTL ? 'المجموع الفرعي' : 'Subtotal'}</span>
                    <span className="text-white">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">{isRTL ? 'الضريبة (5%)' : 'Tax (5%)'}</span>
                    <span className="text-white">${tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold pt-2 border-t border-slate-700">
                    <span className="text-white">{isRTL ? 'الإجمالي' : 'Total'}</span>
                    <span className="text-amber-400">${total.toFixed(2)}</span>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Checkout;