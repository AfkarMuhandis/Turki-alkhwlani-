import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { 
  TrendingUp, TrendingDown, Users, Eye, 
  DollarSign, ShoppingCart, Calendar, Globe,
  Monitor, Smartphone, Tablet, ArrowUpRight, ArrowDownRight
} from 'lucide-react';

const Analytics: React.FC = () => {
  const { isRTL } = useLanguage();
  const [period, setPeriod] = useState('7d');

  const metrics = [
    { 
      title: isRTL ? 'إجمالي الزيارات' : 'Total Visitors', 
      value: '24,589', 
      change: '+12.5%', 
      positive: true, 
      icon: Eye,
      color: 'from-blue-500 to-cyan-500'
    },
    { 
      title: isRTL ? 'المستخدمون الفريدون' : 'Unique Users', 
      value: '18,234', 
      change: '+8.2%', 
      positive: true, 
      icon: Users,
      color: 'from-purple-500 to-pink-500'
    },
    { 
      title: isRTL ? 'الإيرادات' : 'Revenue', 
      value: '$12,458', 
      change: '+23.1%', 
      positive: true, 
      icon: DollarSign,
      color: 'from-green-500 to-emerald-500'
    },
    { 
      title: isRTL ? 'التحويلات' : 'Conversions', 
      value: '4.8%', 
      change: '-2.1%', 
      positive: false, 
      icon: ShoppingCart,
      color: 'from-amber-500 to-orange-500'
    },
  ];

  const topPages = [
    { page: '/', views: 8523, percentage: 35 },
    { page: '/services', views: 4231, percentage: 18 },
    { page: '/blog', views: 3456, percentage: 14 },
    { page: '/store', views: 2891, percentage: 12 },
    { page: '/bookings', views: 2156, percentage: 9 },
  ];

  const trafficSources = [
    { source: isRTL ? 'بحث عضوي' : 'Organic Search', value: 45, color: 'bg-amber-500' },
    { source: isRTL ? 'مباشر' : 'Direct', value: 28, color: 'bg-blue-500' },
    { source: isRTL ? 'وسائل التواصل' : 'Social Media', value: 15, color: 'bg-purple-500' },
    { source: isRTL ? 'إحالات' : 'Referral', value: 12, color: 'bg-green-500' },
  ];

  const deviceStats = [
    { device: 'Desktop', icon: Monitor, percentage: 55, color: 'text-blue-400' },
    { device: 'Mobile', icon: Smartphone, percentage: 38, color: 'text-green-400' },
    { device: 'Tablet', icon: Tablet, percentage: 7, color: 'text-purple-400' },
  ];

  const topCountries = [
    { country: isRTL ? 'السعودية' : 'Saudi Arabia', visits: 12500, flag: '🇸🇦' },
    { country: isRTL ? 'الإمارات' : 'UAE', visits: 4200, flag: '🇦🇪' },
    { country: isRTL ? 'مصر' : 'Egypt', visits: 3100, flag: '🇪🇬' },
    { country: isRTL ? 'الكويت' : 'Kuwait', visits: 2100, flag: '🇰🇼' },
    { country: isRTL ? 'الأردن' : 'Jordan', visits: 1500, flag: '🇯🇴' },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="pt-24 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div>
              <h1 className="text-2xl font-bold text-white">{isRTL ? 'التحليلات' : 'Analytics'}</h1>
              <p className="text-slate-400">{isRTL ? 'نظرة شاملة على أداء موقعك' : 'Comprehensive overview of your site performance'}</p>
            </div>
            <div className="flex gap-2">
              {['7d', '30d', '90d', '1y'].map((p) => (
                <button
                  key={p}
                  onClick={() => setPeriod(p)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    period === p
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {metrics.map((metric, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-900/50 border border-slate-800 rounded-xl p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${metric.color} rounded-xl flex items-center justify-center`}>
                    <metric.icon className="w-6 h-6 text-white" />
                  </div>
                  <span className={`flex items-center gap-1 text-sm font-medium ${metric.positive ? 'text-green-400' : 'text-red-400'}`}>
                    {metric.positive ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                    {metric.change}
                  </span>
                </div>
                <h3 className="text-2xl font-bold text-white">{metric.value}</h3>
                <p className="text-slate-400 text-sm">{metric.title}</p>
              </motion.div>
            ))}
          </div>

          {/* Charts Row */}
          <div className="grid lg:grid-cols-2 gap-6 mb-8">
            {/* Traffic Chart */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">{isRTL ? 'حركة الزيارات' : 'Traffic Overview'}</h3>
              <div className="h-48 flex items-end gap-2">
                {[65, 45, 78, 52, 90, 68, 85, 72, 95, 80, 88, 92].map((height, i) => (
                  <motion.div
                    key={i}
                    initial={{ height: 0 }}
                    animate={{ height: `${height}%` }}
                    transition={{ delay: i * 0.05, duration: 0.5 }}
                    className="flex-1 bg-gradient-to-t from-amber-500 to-amber-400 rounded-t min-h-[10px]"
                  />
                ))}
              </div>
            </div>

            {/* Traffic Sources */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">{isRTL ? 'مصادر الزيارات' : 'Traffic Sources'}</h3>
              <div className="space-y-4">
                {trafficSources.map((source, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-slate-300">{source.source}</span>
                      <span className="text-white font-medium">{source.value}%</span>
                    </div>
                    <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${source.value}%` }}
                        transition={{ delay: 0.5 + i * 0.1, duration: 0.5 }}
                        className={`h-full ${source.color} rounded-full`}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom Row */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Top Pages */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">{isRTL ? 'أفضل الصفحات' : 'Top Pages'}</h3>
              <div className="space-y-3">
                {topPages.map((page, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className="text-slate-500 text-sm">{i + 1}</span>
                      <span className="text-white font-medium text-sm">{page.page}</span>
                    </div>
                    <span className="text-slate-400 text-sm">{page.views.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Device Stats */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">{isRTL ? 'الأجهزة' : 'Devices'}</h3>
              <div className="space-y-4">
                {deviceStats.map((device, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <device.icon className={`w-5 h-5 ${device.color}`} />
                    <div className="flex-1">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-300">{device.device}</span>
                        <span className="text-white">{device.percentage}%</span>
                      </div>
                      <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div className={`h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full`} style={{ width: `${device.percentage}%` }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Countries */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">{isRTL ? 'أفضل الدول' : 'Top Countries'}</h3>
              <div className="space-y-3">
                {topCountries.map((country, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{country.flag}</span>
                      <span className="text-slate-300 text-sm">{country.country}</span>
                    </div>
                    <span className="text-white text-sm">{country.visits.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Analytics;