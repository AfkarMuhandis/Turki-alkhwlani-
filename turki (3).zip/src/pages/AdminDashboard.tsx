import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import { useAuth } from '../lib/auth';
import { ArticleDB, ServiceDB, BookingDB, ProductDB, OrderDB, ContactDB, StatsDB } from '../lib/database';
import Header from '../components/Header';
import Footer from '../components/Footer';
import {
  LayoutDashboard, FileText, Users, ShoppingCart,
  Calendar, Mail, TrendingUp, DollarSign,
  Eye, Package, Plus, Edit, Trash2, Check, X,
  Search, Filter, Download, RefreshCw
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { isRTL } = useLanguage();
  const { user, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [refreshKey, setRefreshKey] = useState(0);

  const refresh = () => setRefreshKey(k => k + 1);

  const stats = StatsDB.getDashboardStats();

  const statCards = [
    { title: isRTL ? 'المقالات' : 'Articles', value: stats.totalArticles, sub: `${stats.publishedArticles} ${isRTL ? 'منشور' : 'published'}`, icon: FileText, color: 'from-blue-500 to-cyan-500' },
    { title: isRTL ? 'الحجوزات' : 'Bookings', value: stats.totalBookings, sub: `${stats.pendingBookings} ${isRTL ? 'معلق' : 'pending'}`, icon: Calendar, color: 'from-purple-500 to-pink-500' },
    { title: isRTL ? 'الطلبات' : 'Orders', value: stats.totalOrders, sub: `${stats.pendingOrders} ${isRTL ? 'معلق' : 'pending'}`, icon: ShoppingCart, color: 'from-amber-500 to-orange-500' },
    { title: isRTL ? 'الإيرادات' : 'Revenue', value: `$${stats.totalRevenue}`, sub: isRTL ? 'إجمالي' : 'Total', icon: DollarSign, color: 'from-green-500 to-emerald-500' },
  ];

  const tabs = [
    { key: 'dashboard', label: isRTL ? 'لوحة التحكم' : 'Dashboard', icon: LayoutDashboard },
    { key: 'articles', label: isRTL ? 'المقالات' : 'Articles', icon: FileText },
    { key: 'bookings', label: isRTL ? 'الحجوزات' : 'Bookings', icon: Calendar },
    { key: 'orders', label: isRTL ? 'الطلبات' : 'Orders', icon: ShoppingCart },
    { key: 'contacts', label: isRTL ? 'الرسائل' : 'Messages', icon: Mail },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="space-y-8">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {statCards.map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-slate-900/50 border border-slate-800 rounded-xl p-6"
                >
                  <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center mb-4`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-3xl font-bold text-white">{stat.value}</div>
                  <div className="text-slate-400 text-sm">{stat.title}</div>
                  <div className="text-amber-400 text-xs mt-1">{stat.sub}</div>
                </motion.div>
              ))}
            </div>
            
            {/* Quick Actions */}
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">{isRTL ? 'إجراءات سريعة' : 'Quick Actions'}</h3>
              <div className="grid sm:grid-cols-3 gap-4">
                <a href="/editor" className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors">
                  <Plus className="w-5 h-5 text-amber-400" />
                  <span className="text-white">{isRTL ? 'مقال جديد' : 'New Article'}</span>
                </a>
                <button className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors">
                  <Calendar className="w-5 h-5 text-purple-400" />
                  <span className="text-white">{isRTL ? 'إضافة حجز' : 'Add Booking'}</span>
                </button>
                <button className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-lg hover:bg-slate-800 transition-colors">
                  <Package className="w-5 h-5 text-green-400" />
                  <span className="text-white">{isRTL ? 'منتج جديد' : 'New Product'}</span>
                </button>
              </div>
            </div>
          </div>
        );

      case 'articles':
        return <ArticlesManager />;

      case 'bookings':
        return <BookingsManager />;

      case 'orders':
        return <OrdersManager />;

      case 'contacts':
        return <ContactsManager />;

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />
      
      <div className="pt-20 flex">
        {/* Sidebar */}
        <aside className="w-64 bg-slate-900/50 border-r border-slate-800 min-h-screen p-4">
          <div className="space-y-2">
            {tabs.map(tab => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  activeTab === tab.key
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <tab.icon className="w-5 h-5" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold text-white capitalize">{activeTab}</h1>
            <button 
              onClick={refresh}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700"
            >
              <RefreshCw className="w-4 h-4" />
              {isRTL ? 'تحديث' : 'Refresh'}
            </button>
          </div>
          {renderContent()}
        </main>
      </div>
      
      <Footer />
    </div>
  );
};

// Articles Manager Component
const ArticlesManager: React.FC = () => {
  const { isRTL } = useLanguage();
  const articles = ArticleDB.getAll();

  const handleDelete = (id: string) => {
    if (confirm(isRTL ? 'هل أنت متأكد؟' : 'Are you sure?')) {
      ArticleDB.delete(id);
      window.location.reload();
    }
  };

  const togglePublish = (id: string, published: boolean) => {
    ArticleDB.update(id, { published: !published });
    window.location.reload();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-white">{isRTL ? 'إدارة المقالات' : 'Manage Articles'}</h2>
        <a href="/editor" className="flex items-center gap-2 px-4 py-2 bg-amber-500 text-slate-950 rounded-lg font-medium">
          <Plus className="w-4 h-4" />
          {isRTL ? 'مقال جديد' : 'New Article'}
        </a>
      </div>
      
      <div className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-800/50">
            <tr>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'العنوان' : 'Title'}</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'الحالة' : 'Status'}</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'المشاهدات' : 'Views'}</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'إجراءات' : 'Actions'}</th>
            </tr>
          </thead>
          <tbody>
            {articles.map(article => (
              <tr key={article.id} className="border-t border-slate-800">
                <td className="p-4 text-white">{article.titleAr || article.titleEn}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded text-xs ${article.published ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                    {article.published ? (isRTL ? 'منشور' : 'Published') : (isRTL ? 'مسودة' : 'Draft')}
                  </span>
                </td>
                <td className="p-4 text-slate-400">{article.views}</td>
                <td className="p-4">
                  <div className="flex gap-2">
                    <a href={`/editor/${article.id}`} className="p-2 text-slate-400 hover:text-amber-400">
                      <Edit className="w-4 h-4" />
                    </a>
                    <button onClick={() => togglePublish(article.id, article.published)} className="p-2 text-slate-400 hover:text-green-400">
                      {article.published ? <X className="w-4 h-4" /> : <Check className="w-4 h-4" />}
                    </button>
                    <button onClick={() => handleDelete(article.id)} className="p-2 text-slate-400 hover:text-red-400">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {articles.length === 0 && (
          <div className="p-8 text-center text-slate-400">
            {isRTL ? 'لا توجد مقالات' : 'No articles found'}
          </div>
        )}
      </div>
    </div>
  );
};

// Bookings Manager Component
const BookingsManager: React.FC = () => {
  const { isRTL } = useLanguage();
  const bookings = BookingDB.getAll();

  const updateStatus = (id: string, status: 'confirmed' | 'completed' | 'cancelled') => {
    BookingDB.updateStatus(id, status);
    window.location.reload();
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-white">{isRTL ? 'إدارة الحجوزات' : 'Manage Bookings'}</h2>
      
      <div className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-800/50">
            <tr>
              <th className="text-left p-4 text-slate-400 font-medium">ID</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'العميل' : 'Client'}</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'الخدمة' : 'Service'}</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'التاريخ' : 'Date'}</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'الحالة' : 'Status'}</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'إجراءات' : 'Actions'}</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map(booking => (
              <tr key={booking.id} className="border-t border-slate-800">
                <td className="p-4 text-slate-300 font-mono text-sm">{booking.id}</td>
                <td className="p-4 text-white">{booking.userName}</td>
                <td className="p-4 text-slate-300">{booking.serviceName}</td>
                <td className="p-4 text-slate-300">{booking.date} {booking.time}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded text-xs ${
                    booking.status === 'confirmed' ? 'bg-green-500/20 text-green-400' :
                    booking.status === 'completed' ? 'bg-blue-500/20 text-blue-400' :
                    booking.status === 'cancelled' ? 'bg-red-500/20 text-red-400' :
                    'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {booking.status}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex gap-2">
                    <button onClick={() => updateStatus(booking.id, 'confirmed')} className="px-3 py-1 bg-green-500/20 text-green-400 rounded text-sm hover:bg-green-500/30">{isRTL ? 'تأكيد' : 'Confirm'}</button>
                    <button onClick={() => updateStatus(booking.id, 'completed')} className="px-3 py-1 bg-blue-500/20 text-blue-400 rounded text-sm hover:bg-blue-500/30">{isRTL ? 'إكمال' : 'Complete'}</button>
                    <button onClick={() => updateStatus(booking.id, 'cancelled')} className="px-3 py-1 bg-red-500/20 text-red-400 rounded text-sm hover:bg-red-500/30">{isRTL ? 'إلغاء' : 'Cancel'}</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// Orders Manager Component
const OrdersManager: React.FC = () => {
  const { isRTL } = useLanguage();
  const orders = OrderDB.getAll();

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-white">{isRTL ? 'إدارة الطلبات' : 'Manage Orders'}</h2>
      
      <div className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-800/50">
            <tr>
              <th className="text-left p-4 text-slate-400 font-medium">ID</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'العميل' : 'Customer'}</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'المجموع' : 'Total'}</th>
              <th className="text-left p-4 text-slate-400 font-medium">{isRTL ? 'الحالة' : 'Status'}</th>
            </tr>
          </thead>
          <tbody>
            {orders.map(order => (
              <tr key={order.id} className="border-t border-slate-800">
                <td className="p-4 text-slate-300 font-mono text-sm">{order.id}</td>
                <td className="p-4 text-white">{order.userName}</td>
                <td className="p-4 text-amber-400 font-medium">${order.total}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded text-xs ${
                    order.status === 'paid' ? 'bg-green-500/20 text-green-400' :
                    order.status === 'completed' ? 'bg-blue-500/20 text-blue-400' :
                    'bg-yellow-500/20 text-yellow-400'
                  }`}>
                    {order.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// Contacts Manager Component
const ContactsManager: React.FC = () => {
  const { isRTL } = useLanguage();
  const contacts = ContactDB.getAll();

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold text-white">{isRTL ? 'إدارة الرسائل' : 'Manage Messages'}</h2>
      
      <div className="space-y-4">
        {contacts.map(contact => (
          <div key={contact.id} className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="text-white font-medium">{contact.name}</h3>
                <p className="text-slate-400 text-sm">{contact.email}</p>
              </div>
              <span className={`px-2 py-1 rounded text-xs ${
                contact.status === 'new' ? 'bg-red-500/20 text-red-400' :
                contact.status === 'read' ? 'bg-yellow-500/20 text-yellow-400' :
                'bg-green-500/20 text-green-400'
              }`}>
                {contact.status}
              </span>
            </div>
            <p className="text-amber-400 text-sm mb-2">{contact.subject}</p>
            <p className="text-slate-300">{contact.message}</p>
            <p className="text-slate-500 text-xs mt-2">
              {new Date(contact.createdAt).toLocaleString()}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminDashboard;