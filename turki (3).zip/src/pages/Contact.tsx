import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import {
  Mail, Phone, MapPin, Send,
  MessageSquare, Clock, CheckCircle,
  Twitter, Linkedin, Youtube, Instagram
} from 'lucide-react';

const Contact: React.FC = () => {
  const { isRTL } = useLanguage();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '', email: '', phone: '', subject: '', message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  const contactInfo = [
    {
      icon: Mail,
      title: isRTL ? 'البريد الإلكتروني' : 'Email',
      value: 'turkiabdus1000@gmail.com',
      href: 'mailto:turkiabdus1000@gmail.com',
    },
    {
      icon: Phone,
      title: isRTL ? 'الهاتف' : 'Phone',
      value: '+967 778 816 043',
      href: 'tel:+967778816043',
    },
    {
      icon: MapPin,
      title: isRTL ? 'الموقع' : 'Location',
      value: isRTL ? 'اليمن' : 'Yemen',
      href: '#',
    },
    {
      icon: Clock,
      title: isRTL ? 'ساعات العمل' : 'Working Hours',
      value: isRTL ? 'السبت - الخميس: 9 ص - 6 م' : 'Sat - Thu: 9 AM - 6 PM',
      href: '#',
    },
  ];

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-slate-950">
        <Header />
        <section className="pt-32 pb-20 flex items-center justify-center min-h-[80vh]">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 0 }} className="text-center max-w-md mx-auto px-4">
            <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">{isRTL ? 'تم الإرسال بنجاح!' : 'Message Sent!'}</h2>
            <p className="text-slate-400 mb-8">
              {isRTL 
                ? 'شكراً لتواصلك معنا، سنرد عليك في أقرب وقت ممكن'
                : 'Thank you for contacting us, we will get back to you as soon as possible'}
            </p>
            <motion.a href="/" className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg" whileHover={{ scale: 1.02 }}>
              {isRTL ? 'العودة للرئيسية' : 'Back to Home'}
            </motion.a>
          </motion.div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'اتصل بنا' : 'Contact Us'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              {isRTL 
                ? 'نسعد بتواصلك معنا! أخبرنا كيف يمكننا مساعدتك'
                : 'We are happy to hear from you! Tell us how we can help'}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Content */}
      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Contact Form */}
            <motion.div 
              initial={{ opacity: 0, x: isRTL ? 50 : -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-3"
            >
              <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-8">
                <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
                  <MessageSquare className="w-7 h-7 text-amber-400" />
                  {isRTL ? 'أرسل لنا رسالة' : 'Send us a message'}
                </h2>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'الاسم الكامل' : 'Full Name'} *</label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        className="w-full py-3 px-4 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                        placeholder={isRTL ? 'أدخل اسمك' : 'Enter your name'}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'البريد الإلكتروني' : 'Email'} *</label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        className="w-full py-3 px-4 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                        placeholder="email@example.com"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'رقم الهاتف' : 'Phone Number'}</label>
                      <input
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        className="w-full py-3 px-4 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
                        placeholder="+967 XXX XXX XXX"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'الموضوع' : 'Subject'} *</label>
                      <select
                        required
                        value={formData.subject}
                        onChange={(e) => setFormData({...formData, subject: e.target.value})}
                        className="w-full py-3 px-4 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-amber-500 transition-colors"
                      >
                        <option value="">{isRTL ? 'اختر الموضوع' : 'Select Subject'}</option>
                        <option value="consultation">{isRTL ? 'استشارة هندسية' : 'Engineering Consultation'}</option>
                        <option value="service">{isRTL ? 'طلب خدمة' : 'Service Request'}</option>
                        <option value="partnership">{isRTL ? 'شراكة' : 'Partnership'}</option>
                        <option value="support">{isRTL ? 'دعم فني' : 'Technical Support'}</option>
                        <option value="other">{isRTL ? 'أخرى' : 'Other'}</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'الرسالة' : 'Message'} *</label>
                    <textarea
                      rows={5}
                      required
                      value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      className="w-full py-3 px-4 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors resize-none"
                      placeholder={isRTL ? 'اكتب رسالتك هنا...' : 'Write your message here...'}
                    />
                  </div>

                  <motion.button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-xl shadow-lg shadow-amber-500/25 hover:shadow-amber-500/40 transition-shadow"
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.99 }}
                  >
                    <Send className="w-5 h-5" />
                    {isRTL ? 'إرسال الرسالة' : 'Send Message'}
                  </motion.button>
                </form>
              </div>
            </motion.div>

            {/* Contact Info Sidebar */}
            <motion.div 
              initial={{ opacity: 0, x: isRTL ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-2 space-y-6"
            >
              {/* Contact Cards */}
              <div className="space-y-4">
                {contactInfo.map((info, index) => (
                  <motion.a
                    key={index}
                    href={info.href}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-start gap-4 p-5 bg-slate-900/50 border border-slate-800 rounded-xl hover:border-amber-500/30 transition-colors group"
                  >
                    <div className="w-12 h-12 bg-amber-500/10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-amber-500/20 transition-colors">
                      <info.icon className="w-6 h-6 text-amber-400" />
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">{info.title}</h3>
                      <p className="text-slate-400 text-sm">{info.value}</p>
                    </div>
                  </motion.a>
                ))}
              </div>

              {/* Social Media */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6">
                <h3 className="text-white font-bold mb-4">{isRTL ? 'تابعنا على' : 'Follow Us On'}</h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { Icon: Twitter, name: 'Twitter' },
                    { Icon: Linkedin, name: 'LinkedIn' },
                    { Icon: Youtube, name: 'YouTube' },
                    { Icon: Instagram, name: 'Instagram' },
                  ].map((social, i) => (
                    <a
                      key={i}
                      href="#"
                      className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-lg hover:bg-slate-800 hover:text-amber-400 text-slate-400 transition-colors"
                    >
                      <social.Icon className="w-5 h-5" />
                      <span className="text-sm font-medium">{social.name}</span>
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-slate-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">{isRTL ? 'الأسئلة الشائعة' : 'Frequently Asked Questions'}</h2>
            <p className="text-slate-400">{isRTL ? 'إجابات على الأسئلة الأكثر شيوعاً' : 'Answers to the most common questions'}</p>
          </motion.div>

          <div className="space-y-4">
            {[
              { q: isRTL ? 'كم تستغرق الاستجابة للاستفسارات؟' : 'How long does it take to respond to inquiries?', a: isRTL ? 'نحاول الرد على جميع الاستفسارات خلال 24 ساعة في أيام العمل.' : 'We try to respond to all inquiries within 24 business hours.' },
              { q: isRTL ? 'هل تقدمون استشارات مجانية؟' : 'Do you offer free consultations?', a: isRTL ? 'نعم، نقدم استشارة أولية مجانية مدتها 30 دقيقة لتقييم احتياجاتك.' : 'Yes, we offer an initial free consultation of 30 minutes to assess your needs.' },
              { q: isRTL ? 'ما هي المناطق التي تغطونها؟' : 'What areas do you cover?', a: isRTL ? 'نقدم خدماتنا في جميع أنحاء اليمن والمنطقة العربية.' : 'We provide our services throughout Yemen and the Arab region.' },
              { q: isRTL ? 'كيف يمكنني الدفع؟' : 'How can I pay?', a: isRTL ? 'نقبل الدفع عبر التحويل البنكي، بطاقات الائتمان، و PayPal.' : 'We accept bank transfers, credit cards, and PayPal.' },
            ].map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-900/50 border border-slate-800 rounded-xl p-6 hover:border-amber-500/20 transition-colors"
              >
                <h3 className="text-lg font-bold text-white mb-2">{faq.q}</h3>
                <p className="text-slate-400">{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Contact;