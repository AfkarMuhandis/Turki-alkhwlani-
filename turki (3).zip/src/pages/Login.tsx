import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../lib/auth';
import { useLanguage } from '../lib/i18n';
import { Mail, Lock, User, ArrowRight, AlertCircle, Eye, EyeOff, Copy, Check } from 'lucide-react';

const Login: React.FC = () => {
  const { isRTL } = useLanguage();
  const { login, register } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isLogin) {
      const success = await login(formData.email, formData.password);
      if (!success) {
        setError(isRTL ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة' : 'Invalid email or password');
      } else {
        window.location.href = '/dashboard';
      }
    } else {
      const success = await register(formData.name, formData.email, formData.password);
      if (!success) {
        setError(isRTL ? 'البريد الإلكتروني مستخدم بالفعل' : 'Email already exists');
      } else {
        window.location.href = '/dashboard';
      }
    }
  };

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopied(field);
    setTimeout(() => setCopied(null), 2000);
  };

  const fillCredentials = (email: string, password: string) => {
    setFormData({ ...formData, email, password });
  };

  const demoAccounts = [
    { role: isRTL ? 'مدير' : 'Admin', email: 'admin@engineerideas.com', password: 'admin123', color: 'from-amber-500 to-amber-600' },
    { role: isRTL ? 'محرر' : 'Editor', email: 'editor@engineerideas.com', password: 'editor123', color: 'from-blue-500 to-blue-600' },
    { role: isRTL ? 'مستخدم' : 'User', email: 'user@test.com', password: 'user123', color: 'from-green-500 to-green-600' },
  ];

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center px-4 py-12">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
      </div>

      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="relative w-full max-w-5xl grid lg:grid-cols-2 gap-8 items-center">
        {/* Login Form */}
        <div className="w-full max-w-md mx-auto lg:mx-0">
          {/* Logo */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center mx-auto mb-4">
              <span className="text-slate-950 font-bold text-2xl">E</span>
            </div>
            <h1 className="text-2xl font-bold text-white">{isRTL ? 'أفكار مهندس' : 'Engineer Ideas'}</h1>
          </div>

          {/* Form Card */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6">
            <h2 className="text-xl font-bold text-white mb-6 text-center">
              {isLogin 
                ? (isRTL ? 'تسجيل الدخول' : 'Sign In')
                : (isRTL ? 'إنشاء حساب' : 'Create Account')}
            </h2>

            {error && (
              <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-2 text-red-400 text-sm">
                <AlertCircle className="w-4 h-4" />
                {error}
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'الاسم الكامل' : 'Full Name'}</label>
                  <div className="relative">
                    <User className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className={`w-full py-3 px-${isRTL ? '4 pr-10' : '4 pl-10'} bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors`}
                      placeholder={isRTL ? 'أدخل اسمك' : 'Enter your name'}
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'البريد الإلكتروني' : 'Email'}</label>
                <div className="relative">
                  <Mail className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                    className={`w-full py-3 px-${isRTL ? '4 pr-10' : '4 pl-10'} bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors`}
                    placeholder="email@example.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'كلمة المرور' : 'Password'}</label>
                <div className="relative">
                  <Lock className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className={`w-full py-3 px-${isRTL ? '4 pr-20' : '4 pl-20'} bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors`}
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className={`absolute top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-white ${isRTL ? 'left-3' : 'right-3'}`}
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <motion.button
                type="submit"
                className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-xl shadow-lg shadow-amber-500/25 hover:shadow-amber-500/40 transition-shadow"
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
              >
                {isLogin ? (isRTL ? 'دخول' : 'Sign In') : (isRTL ? 'إنشاء حساب' : 'Create Account')}
                <ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
              </motion.button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="text-amber-400 hover:text-amber-300 transition-colors text-sm"
              >
                {isLogin 
                  ? (isRTL ? 'ليس لديك حساب؟ سجل الآن' : "Don't have an account? Sign up")
                  : (isRTL ? 'لديك حساب؟ سجل دخولك' : 'Already have an account? Sign in')}
              </button>
            </div>
          </div>
        </div>

        {/* Demo Credentials */}
        <div className="hidden lg:block">
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-white mb-2">{isRTL ? 'بيانات الدخول التجريبية' : 'Demo Login Credentials'}</h3>
            <p className="text-slate-400 text-sm mb-6">{isRTL ? 'انقر على أي حساب لملء البيانات تلقائياً' : 'Click on any account to auto-fill'}</p>

            <div className="space-y-4">
              {demoAccounts.map((account, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => fillCredentials(account.email, account.password)}
                  className="bg-slate-800/50 border border-slate-700 rounded-xl p-4 cursor-pointer hover:border-amber-500/50 transition-all group"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className={`w-10 h-10 bg-gradient-to-br ${account.color} rounded-lg flex items-center justify-center`}>
                      <User className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <span className="text-white font-medium">{account.role}</span>
                      <span className="text-slate-400 text-xs block">{isRTL ? 'حساب تجريبي' : 'Demo Account'}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between bg-slate-900/50 rounded-lg px-3 py-2">
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-slate-500" />
                        <span className="text-slate-300 text-sm">{account.email}</span>
                      </div>
                      <button 
                        onClick={(e) => { e.stopPropagation(); copyToClipboard(account.email, `email-${index}`); }}
                        className="p-1 text-slate-400 hover:text-amber-400 transition-colors"
                      >
                        {copied === `email-${index}` ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>

                    <div className="flex items-center justify-between bg-slate-900/50 rounded-lg px-3 py-2">
                      <div className="flex items-center gap-2">
                        <Lock className="w-4 h-4 text-slate-500" />
                        <span className="text-slate-300 text-sm">{account.password}</span>
                      </div>
                      <button 
                        onClick={(e) => { e.stopPropagation(); copyToClipboard(account.password, `password-${index}`); }}
                        className="p-1 text-slate-400 hover:text-amber-400 transition-colors"
                      >
                        {copied === `password-${index}` ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
              <p className="text-amber-400 text-sm text-center">
                {isRTL 
                  ? '💡 انقر على الحساب لتسجيل الدخول تلقائياً'
                  : '💡 Click on an account to auto-fill and login'}
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Mobile Demo Credentials */}
      <div className="lg:hidden fixed bottom-4 left-4 right-4 z-50">
        <div className="bg-slate-900/95 border border-slate-700 rounded-xl p-4 backdrop-blur-xl">
          <p className="text-white text-sm font-medium mb-2">{isRTL ? 'بيانات الدخول:' : 'Demo Credentials:'}</p>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {demoAccounts.map((account, index) => (
              <button
                key={index}
                onClick={() => fillCredentials(account.email, account.password)}
                className={`flex-shrink-0 px-3 py-1.5 bg-gradient-to-r ${account.color} text-white text-xs font-medium rounded-lg`}
              >
                {account.role}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;