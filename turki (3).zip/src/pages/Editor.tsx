import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import { useAuth } from '../lib/auth';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { 
  Bold, Italic, Underline, List, ListOrdered, 
  Link2, Image, Code, Quote, Heading1, Heading2,
  Save, Eye, Send, ArrowLeft, Settings
} from 'lucide-react';

const Editor: React.FC = () => {
  const { isRTL } = useLanguage();
  const { user, isAdmin } = useAuth();
  const [title, setTitle] = useState('');
  const [titleEn, setTitleEn] = useState('');
  const [content, setContent] = useState('');
  const [contentEn, setContentEn] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [excerptEn, setExcerptEn] = useState('');
  const [category, setCategory] = useState('engineering');
  const [tags, setTags] = useState('');
  const [published, setPublished] = useState(false);
  const [preview, setPreview] = useState(false);
  const [saving, setSaving] = useState(false);

  const categories = [
    { key: 'engineering', label: isRTL ? 'هندسة' : 'Engineering' },
    { key: 'technology', label: isRTL ? 'تقنية' : 'Technology' },
    { key: 'management', label: isRTL ? 'إدارة' : 'Management' },
    { key: 'tutorials', label: isRTL ? 'دروس' : 'Tutorials' },
    { key: 'news', label: isRTL ? 'أخبار' : 'News' },
  ];

  const handleSave = (publish: boolean = false) => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      setPublished(publish);
      alert(publish 
        ? (isRTL ? 'تم نشر المقال!' : 'Article published!')
        : (isRTL ? 'تم حفظ المسودة!' : 'Draft saved!')
      );
    }, 1500);
  };

  const insertFormat = (format: string) => {
    const textarea = document.getElementById('content-editor') as HTMLTextAreaElement;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selected = content.substring(start, end);
    
    let formatted = selected;
    switch (format) {
      case 'bold': formatted = `**${selected}**`; break;
      case 'italic': formatted = `*${selected}*`; break;
      case 'heading1': formatted = `# ${selected}`; break;
      case 'heading2': formatted = `## ${selected}`; break;
      case 'link': formatted = `[${selected}](url)`; break;
      case 'code': formatted = `\`${selected}\``; break;
      case 'quote': formatted = `> ${selected}`; break;
      case 'list': formatted = `- ${selected}`; break;
    }
    
    const newContent = content.substring(0, start) + formatted + content.substring(end);
    setContent(newContent);
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="pt-24 pb-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <a href="/dashboard" className="p-2 text-slate-400 hover:text-white transition-colors">
                <ArrowLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
              </a>
              <h1 className="text-2xl font-bold text-white">
                {isRTL ? 'محرر المقالات' : 'Article Editor'}
              </h1>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setPreview(!preview)}
                className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors"
              >
                <Eye className="w-4 h-4" />
                {isRTL ? 'معاينة' : 'Preview'}
              </button>
              <button
                onClick={() => handleSave(false)}
                disabled={saving}
                className="flex items-center gap-2 px-4 py-2 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors"
              >
                <Save className="w-4 h-4" />
                {saving ? (isRTL ? 'حفظ...' : 'Saving...') : (isRTL ? 'حفظ مسودة' : 'Save Draft')}
              </button>
              <motion.button
                onClick={() => handleSave(true)}
                disabled={saving}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Send className="w-4 h-4" />
                {isRTL ? 'نشر' : 'Publish'}
              </motion.button>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Main Editor */}
            <div className="lg:col-span-2 space-y-6">
              {/* Title */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={isRTL ? 'عنوان المقال بالعربية...' : 'Article title in Arabic...'}
                  className="w-full text-2xl font-bold bg-transparent text-white placeholder-slate-500 focus:outline-none"
                />
                <input
                  type="text"
                  value={titleEn}
                  onChange={(e) => setTitleEn(e.target.value)}
                  placeholder={isRTL ? 'العنوان بالإنجليزية...' : 'Title in English...'}
                  className="w-full text-lg bg-transparent text-slate-300 placeholder-slate-600 focus:outline-none mt-2"
                />
              </div>

              {/* Toolbar */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-2 flex flex-wrap gap-1">
                {[
                  { icon: Bold, format: 'bold', title: 'Bold' },
                  { icon: Italic, format: 'italic', title: 'Italic' },
                  { icon: Heading1, format: 'heading1', title: 'H1' },
                  { icon: Heading2, format: 'heading2', title: 'H2' },
                  { icon: List, format: 'list', title: 'List' },
                  { icon: Link2, format: 'link', title: 'Link' },
                  { icon: Code, format: 'code', title: 'Code' },
                  { icon: Quote, format: 'quote', title: 'Quote' },
                ].map((tool) => (
                  <button
                    key={tool.format}
                    onClick={() => insertFormat(tool.format)}
                    className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-colors"
                    title={tool.title}
                  >
                    <tool.icon className="w-4 h-4" />
                  </button>
                ))}
              </div>

              {/* Content Editor */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden">
                <div className="border-b border-slate-800 px-4 py-2">
                  <span className="text-slate-400 text-sm">{isRTL ? 'المحتوى بالعربية' : 'Content in Arabic'}</span>
                </div>
                <textarea
                  id="content-editor"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  rows={15}
                  placeholder={isRTL ? 'اكتب محتوى المقال هنا...' : 'Write article content here...'}
                  className="w-full p-4 bg-transparent text-white placeholder-slate-500 focus:outline-none resize-none font-mono"
                />
              </div>

              {/* English Content */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden">
                <div className="border-b border-slate-800 px-4 py-2">
                  <span className="text-slate-400 text-sm">{isRTL ? 'المحتوى بالإنجليزية' : 'Content in English'}</span>
                </div>
                <textarea
                  value={contentEn}
                  onChange={(e) => setContentEn(e.target.value)}
                  rows={10}
                  placeholder="Write article content in English..."
                  className="w-full p-4 bg-transparent text-white placeholder-slate-500 focus:outline-none resize-none font-mono"
                />
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Category */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
                <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'التصنيف' : 'Category'}</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white focus:outline-none focus:border-amber-500"
                >
                  {categories.map((cat) => (
                    <option key={cat.key} value={cat.key}>{cat.label}</option>
                  ))}
                </select>
              </div>

              {/* Tags */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
                <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'الوسوم' : 'Tags'}</label>
                <input
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  placeholder={isRTL ? 'وسم1، وسم2، وسم3' : 'tag1, tag2, tag3'}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
                <p className="text-slate-500 text-xs mt-2">{isRTL ? 'افصل بين الوسوم بفاصلة' : 'Separate tags with commas'}</p>
              </div>

              {/* Excerpt */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
                <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'المقتطف' : 'Excerpt'}</label>
                <textarea
                  value={excerpt}
                  onChange={(e) => setExcerpt(e.target.value)}
                  rows={3}
                  placeholder={isRTL ? 'ملخص قصير للمقال...' : 'Brief summary of the article...'}
                  className="w-full px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 resize-none"
                />
              </div>

              {/* Featured Image */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
                <label className="block text-sm font-medium text-slate-300 mb-2">{isRTL ? 'الصورة الرئيسية' : 'Featured Image'}</label>
                <div className="border-2 border-dashed border-slate-700 rounded-lg p-6 text-center hover:border-amber-500/50 transition-colors cursor-pointer">
                  <Image className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                  <p className="text-slate-400 text-sm">{isRTL ? 'اسحب صورة هنا أو انقر للرفع' : 'Drag image here or click to upload'}</p>
                </div>
              </div>

              {/* SEO Settings */}
              <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-4">
                  <Settings className="w-4 h-4 text-amber-400" />
                  <span className="text-white font-medium">{isRTL ? 'إعدادات SEO' : 'SEO Settings'}</span>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Meta Title</label>
                    <input type="text" className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded text-white text-sm" placeholder={title || 'Auto from title'} />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Meta Description</label>
                    <textarea rows={2} className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded text-white text-sm resize-none" placeholder={excerpt || 'Auto from excerpt'} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Editor;