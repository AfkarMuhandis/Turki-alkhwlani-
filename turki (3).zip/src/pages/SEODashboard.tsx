import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';

interface SEOHeadProps {
  title?: string;
  description?: string;
  keywords?: string;
  image?: string;
  url?: string;
  type?: 'website' | 'article' | 'product' | 'service';
  author?: string;
  publishedTime?: string;
  modifiedTime?: string;
}

export const generateSEOHead = ({
  title = 'أفكار مهندس | Engineer Ideas',
  description = 'منصة عربية متكاملة للخدمات الهندسية والاستشارات الفنية والتدريب المهني',
  keywords = 'خدمات هندسية, استشارات, تدريب, هندسة مدنية, تصميم هندسي',
  image = '/og-image.png',
  url = '',
  type = 'website',
  author = 'Engineer Ideas',
  publishedTime,
  modifiedTime,
}: SEOHeadProps = {}) => {
  const siteUrl = 'https://engineerideas.com';
  const fullUrl = `${siteUrl}${url}`;
  const fullImage = image.startsWith('http') ? image : `${siteUrl}${image}`;

  return {
    title,
    description,
    keywords,
    canonical: fullUrl,
    openGraph: {
      type,
      url: fullUrl,
      title,
      description,
      image: fullImage,
      siteName: 'Engineer Ideas',
      locale: 'ar_SA',
      alternateLocale: 'en_US',
    },
    twitter: {
      card: 'summary_large_image',
      site: '@engineerideas',
      creator: '@engineerideas',
      title,
      description,
      image: fullImage,
    },
    article: type === 'article' ? {
      publishedTime,
      modifiedTime,
      author,
    } : undefined,
  };
};

const SEODashboard: React.FC = () => {
  const { isRTL } = useLanguage();

  const seoMetrics = [
    { label: isRTL ? 'الصفحات المفهرسة' : 'Indexed Pages', value: '45', change: '+5' },
    { label: isRTL ? 'الروابط الخلفية' : 'Backlinks', value: '128', change: '+12' },
    { label: isRTL ? 'الدومين أوثورتي' : 'Domain Authority', value: '35', change: '+3' },
    { label: isRTL ? 'سرعة الموقع' : 'Page Speed', value: '92/100', change: '+5' },
  ];

  const checklist = [
    { item: 'Meta Title', status: true },
    { item: 'Meta Description', status: true },
    { item: 'Open Graph Tags', status: true },
    { item: 'Twitter Cards', status: true },
    { item: 'Schema Markup', status: true },
    { item: 'Sitemap.xml', status: true },
    { item: 'Robots.txt', status: true },
    { item: 'Canonical URLs', status: true },
    { item: 'Hreflang Tags', status: true },
    { item: 'Mobile Friendly', status: true },
    { item: 'SSL Certificate', status: true },
    { item: 'Core Web Vitals', status: true },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="pt-24 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-bold text-white mb-8">{isRTL ? 'لوحة SEO' : 'SEO Dashboard'}</h1>

          {/* Metrics */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {seoMetrics.map((metric, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
                <p className="text-slate-400 text-sm mb-1">{metric.label}</p>
                <div className="flex items-center gap-2">
                  <span className="text-2xl font-bold text-white">{metric.value}</span>
                  <span className="text-green-400 text-sm">{metric.change}</span>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Checklist */}
          <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
            <h2 className="text-lg font-bold text-white mb-4">{isRTL ? 'قائمة التحقق من SEO' : 'SEO Checklist'}</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {checklist.map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className={`w-5 h-5 rounded-full flex items-center justify-center ${item.status ? 'bg-green-500' : 'bg-red-500'}`}>
                    {item.status && <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>}
                  </div>
                  <span className="text-slate-300">{item.item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default SEODashboard;