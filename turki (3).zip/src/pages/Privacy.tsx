import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Privacy: React.FC = () => {
  const { isRTL } = useLanguage();

  const sections = [
    {
      title: isRTL ? '1. المعلومات التي نجمعها' : '1. Information We Collect',
      content: isRTL 
        ? 'نجمع معلومات مثل الاسم، البريد الإلكتروني، رقم الهاتف عند التسجيل أو التواصل معنا. نجمع أيضاً معلومات عن استخدامك للموقع لتحسين خدماتنا.'
        : 'We collect information such as name, email, and phone number when you register or contact us. We also collect information about your use of the site to improve our services.'
    },
    {
      title: isRTL ? '2. كيف نستخدم معلوماتك' : '2. How We Use Your Information',
      content: isRTL
        ? 'نستخدم معلوماتك لتقديم الخدمات، التواصل معك، تحسين تجربتك، وإرسال التحديثات والعروض.'
        : 'We use your information to provide services, communicate with you, improve your experience, and send updates and offers.'
    },
    {
      title: isRTL ? '3. مشاركة المعلومات' : '3. Information Sharing',
      content: isRTL
        ? 'لا نشارك معلوماتك مع أطراف ثالثة إلا عند الضرورة القانونية أو بموافقتك.'
        : 'We do not share your information with third parties except when legally required or with your consent.'
    },
    {
      title: isRTL ? '4. أمان البيانات' : '4. Data Security',
      content: isRTL
        ? 'نتخذ إجراءات أمنية مشددة لحماية بياناتك بما في ذلك التشفير والنسخ الاحتياطي.'
        : 'We take strict security measures to protect your data including encryption and backups.'
    },
    {
      title: isRTL ? '5. حقوقك' : '5. Your Rights',
      content: isRTL
        ? 'لك الحق في الوصول لبياناتك، تصحيحها، حذفها، والاعتراض على معالجتها.'
        : 'You have the right to access, correct, delete your data, and object to its processing.'
    },
    {
      title: isRTL ? '6. ملفات تعريف الارتباط' : '6. Cookies',
      content: isRTL
        ? 'نستخدم ملفات تعريف الارتباط لتحسين تجربتك. يمكنك تعطيلها من إعدادات المتصفح.'
        : 'We use cookies to improve your experience. You can disable them from your browser settings.'
    },
    {
      title: isRTL ? '7. تحديثات السياسة' : '7. Policy Updates',
      content: isRTL
        ? 'قد نحدث هذه السياسة من وقت لآخر. سنخطرك بأي تغييرات جوهرية.'
        : 'We may update this policy from time to time. We will notify you of any significant changes.'
    },
    {
      title: isRTL ? '8. التواصل' : '8. Contact',
      content: isRTL
        ? 'لأي استفسارات حول الخصوصية، تواصل معنا على privacy@engineerideas.com'
        : 'For any privacy inquiries, contact us at privacy@engineerideas.com'
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">
              <span className="text-amber-400">{isRTL ? 'سياسة الخصوصية' : 'Privacy Policy'}</span>
            </h1>
            <p className="text-slate-400">{isRTL ? 'آخر تحديث: يناير 2024' : 'Last updated: January 2024'}</p>
          </motion.div>

          <div className="space-y-6">
            {sections.map((section, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-900/50 border border-slate-800 rounded-xl p-6"
              >
                <h2 className="text-lg font-bold text-white mb-3">{section.title}</h2>
                <p className="text-slate-400 leading-relaxed">{section.content}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Privacy;