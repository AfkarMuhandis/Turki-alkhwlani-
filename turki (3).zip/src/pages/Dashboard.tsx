import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Header from '../components/Header';
import Footer from '../components/Footer';
import {
  LayoutDashboard, Users, FileText, ShoppingCart,
  Calendar, Settings, Bell,
  DollarSign, Eye, ArrowUpRight, ArrowDownRight,
  Menu, X
} from 'lucide-react';

import UsersAdmin from './admin/Users';
import ArticlesAdmin from './admin/Articles';
import OrdersAdmin from './admin/Orders';
import BookingsAdmin from './admin/BookingsAdmin';
import SettingsAdmin from './admin/Settings';

const Dashboard: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');

  const menuItems = [
    { key: 'overview', icon: LayoutDashboard, label: 'Overview' },
    { key: 'users', icon: Users, label: 'Users' },
    { key: 'articles', icon: FileText, label: 'Articles' },
    { key: 'orders', icon: ShoppingCart, label: 'Orders' },
    { key: 'bookings', icon: Calendar, label: 'Bookings' },
    { key: 'settings', icon: Settings, label: 'Settings' },
  ];

  const statsCards = [
    { title: 'Revenue', value: '$124,500', change: '+12.5%', positive: true, icon: DollarSign, color: 'from-green-500 to-emerald-600' },
    { title: 'Visitors', value: '45,678', change: '+8.2%', positive: true, icon: Eye, color: 'from-blue-500 to-cyan-600' },
    { title: 'Bookings', value: '23', change: '-2.1%', positive: false, icon: Calendar, color: 'from-purple-500 to-pink-600' },
    { title: 'Orders', value: '156', change: '+18.7%', positive: true, icon: ShoppingCart, color: 'from-amber-500 to-orange-600' },
  ];

  const getStatusColor = (status: string) => {
    if (status === 'completed' || status === 'confirmed') return 'bg-green-500/10 text-green-400';
    if (status === 'processing') return 'bg-blue-500/10 text-blue-400';
    return 'bg-yellow-500/10 text-yellow-400';
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'users': return <UsersAdmin />;
      case 'articles': return <ArticlesAdmin />;
      case 'orders': return <OrdersAdmin />;
      case 'bookings': return <BookingsAdmin />;
      case 'settings': return <SettingsAdmin />;
      default: return (
        <div className="space-y-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {statsCards.map((stat, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-br ${stat.color} rounded-xl flex items-center justify-center`}>
                    <stat.icon className="w-6 h-6 text-white" />
                  </div>
                  <span className={`text-sm ${stat.positive ? 'text-green-400' : 'text-red-400'}`}>
                    {stat.positive ? <ArrowUpRight className="w-4 h-4 inline" /> : <ArrowDownRight className="w-4 h-4 inline" />}
                    {stat.change}
                  </span>
                </div>
                <h3 className="text-2xl font-bold text-white">{stat.value}</h3>
                <p className="text-slate-400 text-sm">{stat.title}</p>
              </motion.div>
            ))}
          </div>
          <div className="grid lg:grid-cols-2 gap-8">
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">Revenue Overview</h3>
              <div className="h-48 flex items-end gap-2">
                {[65, 45, 78, 52, 90, 68, 85].map((h, i) => (
                  <motion.div key={i} initial={{ height: 0 }} animate={{ height: `${h}%` }} transition={{ delay: i * 0.1 }} className="flex-1 bg-gradient-to-t from-amber-500 to-amber-400 rounded-t min-h-[20px]" />
                ))}
              </div>
            </div>
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-6">
              <h3 className="text-lg font-bold text-white mb-6">Traffic Sources</h3>
              {[{ s: 'Organic', v: 45 }, { s: 'Direct', v: 28 }, { s: 'Social', v: 15 }, { s: 'Referral', v: 12 }].map((item, i) => (
                <div key={i} className="mb-4">
                  <div className="flex justify-between text-sm mb-1"><span className="text-slate-300">{item.s}</span><span className="text-white">{item.v}%</span></div>
                  <div className="h-2 bg-slate-800 rounded-full"><div className="h-full bg-amber-500 rounded-full" style={{ width: `${item.v}%` }} /></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
    }
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />
      <div className="pt-20 flex">
        <aside className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-slate-900 border-r border-slate-800 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 transition-transform`}>
          <div className="p-4">
            <div className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-xl mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center">
                <span className="text-slate-950 font-bold">A</span>
              </div>
              <div>
                <p className="text-white font-medium">Admin</p>
                <p className="text-slate-400 text-sm">admin@engineerideas.com</p>
              </div>
            </div>
            <nav className="space-y-1">
              {menuItems.map((item) => (
                <button key={item.key} onClick={() => { setActiveTab(item.key); setSidebarOpen(false); }} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all ${activeTab === item.key ? 'bg-amber-500/10 border border-amber-500/20 text-amber-400' : 'text-slate-400 hover:text-white hover:bg-slate-800/50'}`}>
                  <item.icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </aside>
        {sidebarOpen && <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />}
        <main className="flex-1 min-h-screen">
          <header className="sticky top-20 z-20 bg-slate-950/95 backdrop-blur-xl border-b border-slate-800 px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 text-slate-400 hover:text-white"><Menu className="w-6 h-6" /></button>
                <h1 className="text-xl font-bold text-white capitalize">{activeTab}</h1>
              </div>
              <button className="relative p-2 text-slate-400 hover:text-white"><Bell className="w-5 h-5" /><span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span></button>
            </div>
          </header>
          <div className="p-6">{renderContent()}</div>
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default Dashboard;