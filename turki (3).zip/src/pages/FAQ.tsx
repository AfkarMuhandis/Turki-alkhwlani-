import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { ChevronDown, Search, MessageCircle } from 'lucide-react';

const FAQ: React.FC = () => {
  const { isRTL } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('general');
  const [openItems, setOpenItems] = useState<string[]>([]);

  const categories = [
    { key: 'general', label: isRTL ? 'عام' : 'General' },
    { key: 'services', label: isRTL ? 'الخدمات' : 'Services' },
    { key: 'bookings', label: isRTL ? 'الحجوزات' : 'Bookings' },
    { key: 'store', label: isRTL ? 'المتجر' : 'Store' },
    { key: 'payment', label: isRTL ? 'الدفع' : 'Payment' },
    { key: 'account', label: isRTL ? 'الحساب' : 'Account' },
  ];

  const faqs = [
    // General
    { category: 'general', q: isRTL ? 'ما هي منصة أفكار مهندس؟' : 'What is Engineer Ideas platform?', a: isRTL ? 'منصة أفكار مهندس هي منصة عربية متكاملة تقدم خدمات هندسية واستشارات وحلول ذكية للمهندسين والشركات.' : 'Engineer Ideas is a comprehensive Arabic platform that provides engineering services, consultations, and smart solutions for engineers and companies.' },
    { category: 'general', q: isRTL ? 'كيف يمكنني التواصل معكم؟' : 'How can I contact you?', a: isRTL ? 'يمكنك التواصل معنا عبر صفحة "اتصل بنا" أو عبر البريد الإلكتروني info@engineerideas.com' : 'You can contact us through the "Contact Us" page or via email at info@engineerideas.com' },
    { category: 'general', q: isRTL ? 'هل المنصة متاحة باللغة الإنجليزية؟' : 'Is the platform available in English?', a: isRTL ? 'نعم، المنصة تدعم اللغتين العربية والإنجليزية مع دعم كامل لاتجاه RTL.' : 'Yes, the platform supports both Arabic and English with full RTL support.' },

    // Services
    { category: 'services', q: isRTL ? 'ما هي الخدمات التي تقدمونها؟' : 'What services do you offer?', a: isRTL ? 'نقدم خدمات هندسية متنوعة تشمل التصميم، الاستشارات، التدريب، إدارة المشاريع، والمزيد.' : 'We offer diverse engineering services including design, consultations, training, project management, and more.' },
    { category: 'services', q: isRTL ? 'كم تستغرق الخدمة؟' : 'How long does a service take?', a: isRTL ? 'يختلف الوقت حسب نوع الخدمة وحجم المشروع. يمكنك معرفة التفاصيل في صفحة الخدمات.' : 'Time varies depending on the service type and project size. You can find details on the services page.' },
    { category: 'services', q: isRTL ? 'هل تقدمون ضمان على الخدمات؟' : 'Do you offer a guarantee on services?', a: isRTL ? 'نعم، نقدم ضمان على جميع خدماتنا مع إمكانية التعديلات المجانية.' : 'Yes, we offer a guarantee on all our services with free revisions.' },

    // Bookings
    { category: 'bookings', q: isRTL ? 'كيف أحجز استشارة؟' : 'How do I book a consultation?', a: isRTL ? 'يمكنك حجز استشارة من خلال صفحة الحجوزات، اختر التاريخ والوقت المناسبين ثم املأ البيانات.' : 'You can book a consultation through the bookings page, choose a suitable date and time, then fill in your details.' },
    { category: 'bookings', q: isRTL ? 'هل يمكنني إلغاء الحجز؟' : 'Can I cancel my booking?', a: isRTL ? 'نعم، يمكنك إلغاء الحجز قبل 24 ساعة من الموعد المحدد.' : 'Yes, you can cancel your booking 24 hours before the scheduled time.' },
    { category: 'bookings', q: isRTL ? 'ما هي تكلفة الاستشارة؟' : 'How much does a consultation cost?', a: isRTL ? 'نقدم استشارة أولية مجانية. للاستشارات المتخصصة، تختلف الأسعار حسب نوع الاستشارة.' : 'We offer a free initial consultation. For specialized consultations, prices vary by type.' },

    // Store
    { category: 'store', q: isRTL ? 'ما هي المنتجات المتاحة؟' : 'What products are available?', a: isRTL ? 'نقدم كتب إلكترونية، قوالب، دورات تدريبية، وأدوات هندسية رقمية.' : 'We offer e-books, templates, training courses, and digital engineering tools.' },
    { category: 'store', q: isRTL ? 'كيف أحصل على المنتج بعد الشراء؟' : 'How do I get the product after purchase?', a: isRTL ? 'بعد الشراء، ستصلك رسالة برابط التحميل مباشرة على بريدك الإلكتروني.' : 'After purchase, you will receive an email with a direct download link.' },
    { category: 'store', q: isRTL ? 'هل يمكنني استرداد المنتج؟' : 'Can I get a refund?', a: isRTL ? 'نقدم ضمان استرداد 7 أيام للمنتجات الرقمية إذا لم تكن مطابقة للوصف.' : 'We offer a 7-day refund guarantee for digital products if they do not match the description.' },

    // Payment
    { category: 'payment', q: isRTL ? 'ما هي طرق الدفع المتاحة؟' : 'What payment methods are available?', a: isRTL ? 'نقبل الدفع عبر بطاقات الائتمان (Visa, Mastercard)، PayPal، والتحويل البنكي.' : 'We accept credit cards (Visa, Mastercard), PayPal, and bank transfers.' },
    { category: 'payment', q: isRTL ? 'هل الدفع آمن؟' : 'Is payment secure?', a: isRTL ? 'نعم، نستخدم تشفير SSL وأحدث تقنيات الأمان لحماية بياناتك المالية.' : 'Yes, we use SSL encryption and the latest security technologies to protect your financial data.' },

    // Account
    { category: 'account', q: isRTL ? 'كيف أنشئ حساباً؟' : 'How do I create an account?', a: isRTL ? 'يمكنك إنشاء حساب من خلال صفحة التسجيل، أدخل بياناتك وفعّل حسابك عبر البريد الإلكتروني.' : 'You can create an account through the registration page, enter your details and activate your account via email.' },
    { category: 'account', q: isRTL ? 'كيف أستعيد كلمة المرور؟' : 'How do I recover my password?', a: isRTL ? 'انقر على "نسيت كلمة المرور" في صفحة تسجيل الدخول وأدخل بريدك الإلكتروني لاستلام رابط إعادة التعيين.' : 'Click "Forgot Password" on the login page and enter your email to receive a reset link.' },
  ];

  const filteredFaqs = faqs.filter(faq => 
    (activeCategory === 'all' || faq.category === activeCategory) &&
    (faq.q.toLowerCase().includes(searchQuery.toLowerCase()) || faq.a.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const toggleItem = (index: string) => {
    setOpenItems(prev => prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]);
  };

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero */}
      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'الأسئلة الشائعة' : 'FAQ'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed mb-8">
              {isRTL ? 'إجابات على الأسئلة الأكثر شيوعاً' : 'Answers to the most common questions'}
            </p>

            {/* Search */}
            <div className="relative max-w-xl mx-auto">
              <Search className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 ${isRTL ? 'right-4' : 'left-4'}`} />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={isRTL ? 'ابحث عن سؤال...' : 'Search for a question...'}
                className={`w-full py-4 px-${isRTL ? '4 pr-12' : '4 pl-12'} bg-slate-900/80 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors`}
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((cat) => (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className={`px-5 py-2.5 rounded-lg font-medium transition-all ${
                  activeCategory === cat.key
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg'
                    : 'bg-slate-800/50 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-4">
            {filteredFaqs.map((faq, index) => {
              const itemKey = `${faq.category}-${index}`;
              const isOpen = openItems.includes(itemKey);
              return (
                <motion.div
                  key={itemKey}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-slate-900/50 border border-slate-800 rounded-xl overflow-hidden"
                >
                  <button
                    onClick={() => toggleItem(itemKey)}
                    className="w-full flex items-center justify-between p-5 text-left hover:bg-slate-800/30 transition-colors"
                  >
                    <span className="text-white font-medium">{faq.q}</span>
                    <ChevronDown className={`w-5 h-5 text-amber-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {isOpen && (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="px-5 pb-5">
                      <p className="text-slate-400">{faq.a}</p>
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>

          {filteredFaqs.length === 0 && (
            <div className="text-center py-12">
              <p className="text-slate-400">{isRTL ? 'لا توجد نتائج مطابقة' : 'No matching results found'}</p>
            </div>
          )}
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-slate-900/30">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <MessageCircle className="w-12 h-12 text-amber-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-white mb-4">{isRTL ? 'لم تجد إجابة؟' : 'Didn\'t find an answer?'}</h2>
          <p className="text-slate-400 mb-8">{isRTL ? 'تواصل معنا مباشرة وسنساعدك' : 'Contact us directly and we\'ll help you'}</p>
          <motion.a href="/contact" className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg" whileHover={{ scale: 1.02 }}>
            {isRTL ? 'تواصل معنا' : 'Contact Us'}
          </motion.a>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default FAQ;