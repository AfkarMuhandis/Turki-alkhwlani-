import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { 
  Target, Eye, Heart, Users, Award, Clock,
  CheckCircle, ArrowRight, Lightbulb
} from 'lucide-react';

const About: React.FC = () => {
  const { t, isRTL } = useLanguage();

  const values = [
    {
      icon: Target,
      title: isRTL ? 'التميز' : 'Excellence',
      desc: isRTL ? 'نسعى للتميز في كل ما نقدمه من خدمات وحلول هندسية' : 'We strive for excellence in every service and engineering solution we provide'
    },
    {
      icon: Heart,
      title: isRTL ? 'النزاهة' : 'Integrity',
      desc: isRTL ? 'نعمل بشفافية وأمانة مع جميع عملائنا وشركائنا' : 'We work with transparency and integrity with all our clients and partners'
    },
    {
      icon: Users,
      title: isRTL ? 'التعاون' : 'Collaboration',
      desc: isRTL ? 'نؤمن بقوة العمل الجماعي والشراكات الاستراتيجية' : 'We believe in the power of teamwork and strategic partnerships'
    },
    {
      icon: Lightbulb,
      title: isRTL ? 'الابتكار' : 'Innovation',
      desc: isRTL ? 'نتبنى أحدث التقنيات والحلول المبتكرة في مشاريعنا' : 'We adopt the latest technologies and innovative solutions in our projects'
    },
  ];

  const team = [
    {
      name: isRTL ? 'م. أحمد الراشد' : 'Eng. Ahmed Al-Rashid',
      role: isRTL ? 'المدير التنفيذي & المؤسس' : 'CEO & Founder',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400'
    },
    {
      name: isRTL ? 'م. سارة المنصور' : 'Eng. Sara Al-Mansour',
      role: isRTL ? 'مديرة التصميم الهندسي' : 'Engineering Design Manager',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400'
    },
    {
      name: isRTL ? 'م. خالد الشمري' : 'Eng. Khaled Al-Shammari',
      role: isRTL ? 'مدير المشاريع' : 'Project Manager',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400'
    },
    {
      name: isRTL ? 'م. نورة القحطاني' : 'Eng. Noura Al-Qahtani',
      role: isRTL ? 'مديرة الاستشارات' : 'Consultations Manager',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400'
    },
  ];

  const timeline = [
    {
      year: '2009',
      title: isRTL ? 'التأسيس' : 'Foundation',
      desc: isRTL ? 'تأسيس الشركة كفريق صغير من المهندسين المتحمسين' : 'Founded as a small team of passionate engineers'
    },
    {
      year: '2013',
      title: isRTL ? 'التوسع' : 'Expansion',
      desc: isRTL ? 'التوسع لتقديم خدمات شاملة في مجالات متعددة' : 'Expanded to offer comprehensive services in multiple fields'
    },
    {
      year: '2017',
      title: isRTL ? 'التحول الرقمي' : 'Digital Transformation',
      desc: isRTL ? 'إطلاق المنصة الرقمية وخدمات الاستشارات عن بُعد' : 'Launched digital platform and remote consultation services'
    },
    {
      year: '2023',
      title: isRTL ? 'الريادة الإقليمية' : 'Regional Leadership',
      desc: isRTL ? 'الوصول لأكثر من 500 مشروع و350 عميل راضٍ' : 'Reached over 500 projects and 350 satisfied clients'
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-center max-w-3xl mx-auto ${isRTL ? '' : ''}`}
          >
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              {isRTL ? (
                <>
                  <span className="text-amber-400">{t.nav.about}</span>
                </>
              ) : (
                <>
                  <span className="text-amber-400">About Us</span>
                </>
              )}
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              {isRTL 
                ? 'نحن فريق من المهندسين المحترفين نسعى لتقديم أفضل الحلول الهندسية والمبتكرة لعملائنا حول العالم'
                : 'We are a team of professional engineers striving to provide the best engineering solutions and innovations for our clients worldwide'}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            <motion.div
          initial={{ opacity: 0, x: isRTL ? 50 : -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-amber-500/10 to-transparent border border-amber-500/20 rounded-2xl p-8"
        >
          <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center mb-6">
            <Target className="w-8 h-8 text-slate-950" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">{isRTL ? 'رسالتنا' : 'Our Mission'}</h3>
          <p className="text-slate-300 leading-relaxed">
            {isRTL 
              ? 'تقديم حلول هندسية مبتكرة وعالية الجودة تساعد عملاءنا على تحقيق أهدافهم وتجاوز توقعاتهم، مع الالتزام بأعلى معايير الاحترافية والأخلاق.'
              : 'To provide innovative and high-quality engineering solutions that help our clients achieve their goals and exceed expectations, while adhering to the highest standards of professionalism and ethics.'}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: isRTL ? -50 : 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-blue-500/10 to-transparent border border-blue-500/20 rounded-2xl p-8"
        >
          <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center mb-6">
            <Eye className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">{isRTL ? 'رؤيتنا' : 'Our Vision'}</h3>
          <p className="text-slate-300 leading-relaxed">
            {isRTL 
              ? 'أن نكون المنصة الهندسية الرائدة إقليمياً وعالمياً، ومرجعاً موثوقاً للحلول الهندسية المبتكرة والمستدامة.'
              : 'To be the leading engineering platform regionally and globally, and a trusted reference for innovative and sustainable engineering solutions.'}
          </p>
        </motion.div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-24 bg-slate-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">{isRTL ? 'قيمنا' : 'Our Values'}</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              {isRTL ? 'المبادئ التي توجه عملنا وتحدد هويتنا' : 'The principles that guide our work define our identity'}
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 hover:border-amber-500/30 transition-colors group"
              >
                <div className="w-14 h-14 bg-amber-500/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-amber-500/20 transition-colors">
                  <value.icon className="w-7 h-7 text-amber-400" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{value.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{value.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">{isRTL ? 'رحلتنا' : 'Our Journey'}</h2>
            <p className="text-slate-400">{isRTL ? 'محطات مهمة في تاريخنا' : 'Important milestones in our history'}</p>
          </motion.div>

          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute top-0 bottom-0 w-px bg-amber-500/30 left-1/2 transform -translate-x-1/2 hidden md:block" />

            <div className="space-y-12">
              {timeline.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.15 }}
                  className={`relative flex items-center ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}
                >
                  <div className={`flex-1 ${index % 2 === 0 ? (isRTL ? 'md:text-left md:pr-12' : 'md:text-right md:pr-12') : (isRTL ? 'md:text-right md:pl-12' : 'md:text-left md:pl-12')}`}>
                    <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 hover:border-amber-500/20 transition-colors">
                      <span className="text-amber-400 font-bold text-lg">{item.year}</span>
                      <h3 className="text-xl font-bold text-white mt-2 mb-2">{item.title}</h3>
                      <p className="text-slate-400">{item.desc}</p>
                    </div>
                  </div>

                  {/* Center Dot */}
                  <div className="hidden md:flex absolute left-1/2 transform -translate-x-1/2 w-12 h-12 bg-slate-950 border-4 border-amber-500 rounded-full items-center justify-center">
                    <div className="w-3 h-3 bg-amber-400 rounded-full" />
                  </div>

                  <div className="flex-1 hidden md:block" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-24 bg-slate-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">{isRTL ? 'فريقنا' : 'Our Team'}</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">
              {isRTL ? 'نخبة من المهندسين والخبراء المتخصصين' : 'A selection of specialized engineers and experts'}
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden hover:border-amber-500/30 transition-all"
              >
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={member.image} 
                    alt={member.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-bold text-white mb-1">{member.name}</h3>
                  <p className="text-amber-400 text-sm">{member.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="bg-gradient-to-r from-amber-500/20 to-amber-600/10 border border-amber-500/30 rounded-3xl p-8 sm:p-12 text-center"
          >
            <h2 className="text-3xl font-bold text-white mb-4">{isRTL ? 'هل تريد الانضمام لفريقنا؟' : 'Want to Join Our Team?'}</h2>
            <p className="text-slate-300 mb-8 max-w-xl mx-auto">
              {isRTL ? 'نحن دائماً نبحث عن المواهب المتميزة للانضمام إلى فريقنا' : 'We are always looking for exceptional talents to join our team'}
            </p>
            <motion.a
              href="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg shadow-lg shadow-amber-500/25"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {isRTL ? 'تواصل معنا' : 'Contact Us'}
              <ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
            </motion.a>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;