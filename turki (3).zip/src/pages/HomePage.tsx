import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { 
  Wrench, MessageSquare, Users, PenTool, 
  ArrowRight, Star, CheckCircle, Zap,
  Building2, HardHat, Calculator, FileText,
  Calendar, Clock, Shield, Award
} from 'lucide-react';

const HomePage: React.FC = () => {
  const { t, isRTL } = useLanguage();

  const stats = [
    { value: '500+', label: t.stats.projects, icon: Building2 },
    { value: '350+', label: t.stats.clients, icon: Users },
    { value: '15+', label: t.stats.experience, icon: Clock },
    { value: '99%', label: t.stats.satisfaction, icon: Award },
  ];

  const services = [
    { 
      title: t.services.engineering, 
      description: isRTL ? 'حلول هندسية متكاملة لمشاريعك الكبرى' : 'Comprehensive engineering solutions for your major projects',
      icon: Wrench,
      color: 'from-amber-500 to-orange-500',
      href: '/services/engineering'
    },
    { 
      title: t.services.consulting, 
      description: isRTL ? 'استشارات فنية من خبراء المجال' : 'Technical consultations from field experts',
      icon: MessageSquare,
      color: 'from-blue-500 to-cyan-500',
      href: '/services/consulting'
    },
    { 
      title: t.services.training, 
      description: isRTL ? 'برامج تدريبية احترافية للمهندسين' : 'Professional training programs for engineers',
      icon: Users,
      color: 'from-purple-500 to-pink-500',
      href: '/services/training'
    },
    { 
      title: t.services.design, 
      description: isRTL ? 'تصاميم هندسية مبتكرة ودقيقة' : 'Innovate and precise engineering designs',
      icon: PenTool,
      color: 'from-green-500 to-emerald-500',
      href: '/services/design'
    },
  ];

  const features = [
    { icon: Shield, title: isRTL ? 'جودة عالية' : 'High Quality', desc: isRTL ? 'نضمن أعلى معايير الجودة' : 'We guarantee the highest quality standards' },
    { icon: Clock, title: isRTL ? 'التزام بالمواعيد' : 'On-Time Delivery', desc: isRTL ? 'نلتزم بتسليم المشاريع في وقتها' : 'We commit to delivering projects on time' },
    { icon: Calculator, title: isRTL ? 'أسعار تنافسية' : 'Competitive Pricing', desc: isRTL ? 'أسعار منافسة دون تنازل عن الجودة' : 'Competitive prices without compromising quality' },
    { icon: HardHat, title: isRTL ? 'فريق محترف' : 'Professional Team', desc: isRTL ? 'فريق من المهندسين المحترفين' : 'A team of professional engineers' },
  ];

  const testimonials = [
    {
      name: isRTL ? 'أحمد محمد' : 'Ahmed Mohammed',
      role: isRTL ? 'مدير مشاريع' : 'Project Manager',
      content: isRTL 
        ? 'تجربة ممتازة مع فريق أفكار مهندس. خدمة احترافية وجودة عالية في التنفيذ.'
        : 'Excellent experience with Engineer Ideas team. Professional service and high quality execution.',
      rating: 5,
    },
    {
      name: isRTL ? 'سارة علي' : 'Sara Ali',
      role: isRTL ? 'مهندسة مدنية' : 'Civil Engineer',
      content: isRTL 
        ? 'الاستشارات المقدمة ساعدتني كثيراً في تطوير مهاراتي وحل المشكلات التقنية.'
        : 'The consultations provided helped me a lot in developing my skills and solving technical problems.',
      rating: 5,
    },
    {
      name: isRTL ? 'خالد العتيبي' : 'Khaled Al-Otaibi',
      role: isRTL ? 'رجل أعمال' : 'Businessman',
      content: isRTL 
        ? 'أنجزوا مشروعي بكفاءة عالية وفي الوقت المحدد. أنصح بالتعامل معهم.'
        : 'They completed my project efficiently and on time. I recommend dealing with them.',
      rating: 5,
    },
  ];

  const blogPosts = [
    {
      title: isRTL ? 'أحدث تقنيات البناء المستدام' : 'Latest Sustainable Building Technologies',
      excerpt: isRTL ? 'تعرف على أحدث التقنيات في مجال البناء المستود والصديق للبيئة...' : 'Learn about the latest technologies in sustainable and eco-friendly construction...',
      image: 'https://images.unsplash.com/photo-1504307651250-9786c063a6c7?w=800',
      date: isRTL ? '15 يناير 2024' : 'Jan 15, 2024',
      category: isRTL ? 'تقنيات' : 'Technology',
    },
    {
      title: isRTL ? 'دليل شامل لإدارة المشاريع الهندسية' : 'Comprehensive Guide to Engineering Project Management',
      excerpt: isRTL ? 'نصائح وإرشادات لإدارة المشاريع الهندسية بكفاءة واحترافية...' : 'Tips and guidelines for managing engineering projects efficiently and professionally...',
      image: 'https://images.unsplash.com/photo-1531834685032-cd5634b1f8e7?w=800',
      date: isRTL ? '10 يناير 2024' : 'Jan 10, 2024',
      category: isRTL ? 'إدارة' : 'Management',
    },
    {
      title: isRTL ? 'مستقبل الهندسة المدنية' : 'Future of Civil Engineering',
      excerpt: isRTL ? 'نظرة على المستقبل وما يحمله من تطورات في مجال الهندسة المدنية...' : 'A look at the future and the developments it holds in the field of civil engineering...',
      image: 'https://images.unsplash.com/photo-1581094794329-c8112a89af5a?w=800',
      date: isRTL ? '5 يناير 2024' : 'Jan 5, 2024',
      category: isRTL ? 'مستقبل' : 'Future',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-amber-800/10 via-transparent to-transparent" />
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-amber-600/5 rounded-full blur-3xl" />
        </div>

        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(to right, rgba(245, 158, 11, 0.1) 1px, transparent 1px), linear-gradient(to bottom, rgba(245, 158, 11, 0.1) 1px, transparent 1px)`,
            backgroundSize: '60px 60px'
          }} />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: isRTL ? 50 : -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className={isRTL ? 'text-right lg:order-2' : 'text-left lg:order-1'}
            >
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500/10 border border-amber-500/20 rounded-full text-amber-400 text-sm font-medium mb-6"
              >
                <Zap className="w-4 h-4" />
                {isRTL ? 'منصة هندسية متكاملة' : 'Complete Engineering Platform'}
              </motion.div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
                {isRTL ? (
                  <>
                    <span className="text-amber-400">أفكار مهندس</span>
                    <br />
                    <span className="text-2xl sm:text-3xl lg:text-4xl font-normal text-slate-300">منصتك الهندسية المتكاملة</span>
                  </>
                ) : (
                  <>
                    <span className="text-amber-400">Engineer Ideas</span>
                    <br />
                    <span className="text-2xl sm:text-3xl lg:text-4xl font-normal text-slate-300">Your Complete Engineering Platform</span>
                  </>
                )}
              </h1>

              <p className="text-lg text-slate-400 mb-8 max-w-xl leading-relaxed">{t.hero.subtitle}</p>

              <div className="flex flex-wrap gap-4">
                <motion.a
                  href="/services"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg shadow-lg shadow-amber-500/25 hover:shadow-amber-500/40 transition-shadow"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {t.hero.cta}
                  <ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                </motion.a>
                <motion.a
                  href="/bookings"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-slate-800/50 border border-slate-700 text-white font-medium rounded-lg hover:border-amber-500/50 hover:text-amber-400 transition-colors"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Calendar className="w-5 h-5" />
                  {t.hero.cta2}
                </motion.a>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className={`relative ${isRTL ? 'lg:order-1' : 'lg:order-2'}`}
            >
              <div className="relative">
                <div className="relative bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-amber-500/20 rounded-2xl p-8 shadow-2xl">
                  <div className="grid grid-cols-2 gap-4">
                    {services.map((service, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5 + index * 0.1 }}
                        className="group bg-slate-800/50 border border-slate-700/50 rounded-xl p-4 hover:border-amber-500/30 transition-all cursor-pointer"
                      >
                        <div className={`w-12 h-12 bg-gradient-to-br ${service.color} rounded-lg flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                          <service.icon className="w-6 h-6 text-white" />
                        </div>
                        <h3 className="text-white font-medium text-sm">{service.title}</h3>
                      </motion.div>
                    ))}
                  </div>
                </div>

                <motion.div 
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 3, repeat: Infinity }}
                  className="absolute -top-6 -right-6 bg-gradient-to-br from-amber-500 to-amber-600 rounded-xl p-4 shadow-lg shadow-amber-500/30"
                >
                  <CheckCircle className="w-8 h-8 text-slate-950" />
                </motion.div>
                
                <motion.div 
                  animate={{ y: [0, 10, 0] }}
                  transition={{ duration: 4, repeat: Infinity }}
                  className="absolute -bottom-4 -left-4 bg-slate-800 border border-amber-500/20 rounded-xl p-4 shadow-xl"
                >
                  <div className="flex items-center gap-2">
                    <div className="flex -space-x-2">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="w-8 h-8 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full border-2 border-slate-800" />
                      ))}
                    </div>
                    <span className="text-white text-sm font-medium">350+</span>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="relative py-16 bg-slate-900/50 border-y border-amber-500/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="inline-flex items-center justify-center w-14 h-14 bg-amber-500/10 rounded-xl mb-4">
                  <stat.icon className="w-7 h-7 text-amber-400" />
                </div>
                <div className="text-4xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-slate-400">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">{t.services.title}</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">{t.services.subtitle}</p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <motion.a
                key={index}
                href={service.href}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group relative bg-slate-900/50 border border-slate-800 rounded-2xl p-6 hover:border-amber-500/30 transition-all overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-amber-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className={`w-14 h-14 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <service.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{service.title}</h3>
                <p className="text-slate-400 text-sm mb-4">{service.description}</p>
                <div className="flex items-center gap-2 text-amber-400 font-medium text-sm">
                  <span>{isRTL ? 'اعرف المزيد' : 'Learn More'}</span>
                  <ArrowRight className={`w-4 h-4 group-hover:translate-x-1 transition-transform ${isRTL ? 'rotate-180' : ''}`} />
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-slate-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div initial={{ opacity: 0, x: isRTL ? 50 : -50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">{isRTL ? 'لماذا تختارنا؟' : 'Why Choose Us?'}</h2>
              <p className="text-slate-400 mb-8">{isRTL ? 'نقدم لك مزايا فريدة تجعلنا الخيار الأمثل لتحقيق أهدافك الهندسية' : 'We offer you unique advantages that make us the optimal choice for achieving your engineering goals'}</p>
              <div className="grid sm:grid-cols-2 gap-6">
                {features.map((feature, index) => (
                  <motion.div key={index} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }} className="flex gap-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-amber-500/10 rounded-xl flex items-center justify-center">
                      <feature.icon className="w-6 h-6 text-amber-400" />
                    </div>
                    <div>
                      <h3 className="text-white font-medium mb-1">{feature.title}</h3>
                      <p className="text-slate-400 text-sm">{feature.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, x: isRTL ? -50 : 50 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} className="relative">
              <div className="relative bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl p-8 border border-amber-500/20">
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl" />
                <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-amber-600/10 rounded-full blur-2xl" />
                
                <div className="relative">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center">
                      <Award className="w-8 h-8 text-slate-950" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">{isRTL ? 'سنوات من الخبرة' : 'Years of Experience'}</h3>
                      <p className="text-amber-400">15+ {isRTL ? 'سنة' : 'Years'}</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {[isRTL ? 'فريق من المهندسين المحترفين' : 'Team of professional engineers', isRTL ? 'مشاريع ناجحة في مختلف المجالات' : 'Successful projects in various fields', isRTL ? 'شراكات استراتيجية مع كبرى الشركات' : 'Strategic partnerships with major companies', isRTL ? 'تقنيات حديثة ومتطورة' : 'Modern and advanced technologies'].map((item, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-amber-400 flex-shrink-0" />
                        <span className="text-slate-300">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">{isRTL ? 'ماذا يقول عملاؤنا' : 'What Our Clients Say'}</h2>
            <p className="text-slate-400 max-w-2xl mx-auto">{isRTL ? 'آراء حقيقية من عملاء حقيقيين جربوا خدماتنا' : 'Real reviews from real clients who experienced our services'}</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <motion.div key={index} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }} className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 hover:border-amber-500/20 transition-colors">
                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (<Star key={i} className="w-5 h-5 text-amber-400 fill-amber-400" />))}
                </div>
                <p className="text-slate-300 mb-6 leading-relaxed">"{testimonial.content}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full" />
                  <div>
                    <h4 className="text-white font-medium">{testimonial.name}</h4>
                    <p className="text-slate-400 text-sm">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-slate-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-12">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-2">{isRTL ? 'أحدث المقالات' : 'Latest Articles'}</h2>
              <p className="text-slate-400">{isRTL ? 'آخر الأخبار والمقالات من مدونتنا' : 'Latest news and articles from our blog'}</p>
            </div>
            <motion.a href="/blog" className="inline-flex items-center gap-2 text-amber-400 font-medium hover:text-amber-300 transition-colors" whileHover={{ x: isRTL ? -5 : 5 }}>
              {isRTL ? 'عرض الكل' : 'View All'}<ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
            </motion.a>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {blogPosts.map((post, index) => (
              <motion.a key={index} href="/blog" initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: index * 0.1 }} className="group bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden hover:border-amber-500/20 transition-colors">
                <div className="relative h-48 overflow-hidden">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-transparent opacity-60" />
                  <div className="absolute top-4 left-4"><span className="px-3 py-1 bg-amber-500 text-slate-950 text-xs font-bold rounded-full">{post.category}</span></div>
                </div>
                <div className="p-6">
                  <p className="text-slate-500 text-sm mb-2">{post.date}</p>
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-amber-400 transition-colors line-clamp-2">{post.title}</h3>
                  <p className="text-slate-400 text-sm line-clamp-2">{post.excerpt}</p>
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="relative bg-gradient-to-br from-amber-500/20 via-amber-600/10 to-amber-500/20 border border-amber-500/30 rounded-3xl p-8 sm:p-12 text-center overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent" />
            
            <div className="relative">
              <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">{isRTL ? 'جاهز للبدء؟' : 'Ready to Get Started?'}</h2>
              <p className="text-slate-300 mb-8 max-w-xl mx-auto">{isRTL ? 'تواصل معنا اليوم واحصل على استشارة مجانية لمشروعك' : 'Contact us today and get a free consultation for your project'}</p>
              <div className="flex flex-wrap justify-center gap-4">
                <motion.a href="/contact" className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg shadow-lg shadow-amber-500/25 hover:shadow-amber-500/40 transition-shadow" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  {isRTL ? 'تواصل معنا' : 'Contact Us'}<ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                </motion.a>
                <motion.a href="/bookings" className="inline-flex items-center gap-2 px-8 py-4 bg-slate-800/50 border border-slate-700 text-white font-medium rounded-lg hover:border-amber-500/50 hover:text-amber-400 transition-colors" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Calendar className="w-5 h-5" />{isRTL ? 'احجز موعد' : 'Book Now'}
                </motion.a>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default HomePage;