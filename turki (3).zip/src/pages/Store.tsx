import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import {
  ShoppingCart, Star, Heart, Search,
  BookOpen, Layout, FileText, GraduationCap,
  Plus, Minus, X
} from 'lucide-react';

const Store: React.FC = () => {
  const { isRTL } = useLanguage();
  const [activeCategory, setActiveCategory] = useState('all');
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useState<{id: number; title: string; price: string; quantity: number}[]>([]);

  const categories = [
    { key: 'all', label: isRTL ? 'الكل' : 'All' },
    { key: 'books', label: isRTL ? 'كتب' : 'Books' },
    { key: 'templates', label: isRTL ? 'قوالب' : 'Templates' },
    { key: 'courses', label: isRTL ? 'دورات' : 'Courses' },
    { key: 'tools', label: isRTL ? 'أدوات' : 'Tools' },
  ];

  const products = [
    {
      id: 1,
      title: isRTL ? 'دليل المهندس المدني الشامل' : 'Complete Civil Engineer Guide',
      category: 'books',
      price: isRTL ? '99 ر.س' : '$26',
      oldPrice: isRTL ? '149 ر.س' : '$40',
      image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400',
      rating: 4.9,
      reviews: 127,
      icon: BookOpen,
    },
    {
      id: 2,
      title: isRTL ? 'قوالب AutoCAD احترافية' : 'Professional AutoCAD Templates',
      category: 'templates',
      price: isRTL ? '149 ر.س' : '$40',
      image: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=400',
      rating: 4.8,
      reviews: 89,
      icon: Layout,
    },
    {
      id: 3,
      title: isRTL ? 'دورة BIM المتقدمة' : 'Advanced BIM Course',
      category: 'courses',
      price: isRTL ? '499 ر.س' : '$133',
      oldPrice: isRTL ? '799 ر.س' : '$213',
      image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400',
      rating: 5.0,
      reviews: 256,
      icon: GraduationCap,
    },
    {
      id: 4,
      title: isRTL ? 'حاسبة الخرسانة المسلحة' : 'Reinforced Concrete Calculator',
      category: 'tools',
      price: isRTL ? '79 ر.س' : '$21',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400',
      rating: 4.7,
      reviews: 64,
      icon: FileText,
    },
    {
      id: 5,
      title: isRTL ? 'كتاب إدارة المشاريع الهندسية' : 'Engineering Project Management Book',
      category: 'books',
      price: isRTL ? '89 ر.س' : '$24',
      image: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400',
      rating: 4.6,
      reviews: 93,
      icon: BookOpen,
    },
    {
      id: 6,
      title: isRTL ? 'قوالب Revit للتصميم المعماري' : 'Revit Architectural Templates',
      category: 'templates',
      price: isRTL ? '199 ر.س' : '$53',
      oldPrice: isRTL ? '299 ر.س' : '$80',
      image: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=400',
      rating: 4.8,
      reviews: 112,
      icon: Layout,
    },
    {
      id: 7,
      title: isRTL ? 'دورة SAP2000 من الصفر للاحتراف' : 'SAP2000 Zero to Pro Course',
      category: 'courses',
      price: isRTL ? '349 ر.س' : '$93',
      image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400',
      rating: 4.9,
      reviews: 178,
      icon: GraduationCap,
    },
    {
      id: 8,
      title: isRTL ? 'حزمة أدوات Excel للمهندسين' : 'Excel Tools Pack for Engineers',
      category: 'tools',
      price: isRTL ? '59 ر.س' : '$16',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400',
      rating: 4.5,
      reviews: 203,
      icon: FileText,
    },
  ];

  const filteredProducts = activeCategory === 'all' ? products : products.filter(p => p.category === activeCategory);

  const addToCart = (product: typeof products[0]) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) return prev.map(item => item.id === product.id ? {...item, quantity: item.quantity + 1} : item);
      return [...prev, { id: product.id, title: product.title, price: product.price, quantity: 1 }];
    });
  };

  const updateCartQuantity = (id: number, delta: number) => {
    setCart(prev => prev.map(item => item.id === id ? {...item, quantity: Math.max(1, item.quantity + delta)} : item));
  };

  const removeFromCart = (id: number) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const cartTotal = cart.reduce((sum, item) => sum + (parseFloat(item.price.replace(/[^\d.]/g, '')) * item.quantity), 0);

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'المتجر' : 'Store'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">{isRTL ? 'كتب وقوالب ودورات وأدوات لمهندسي المستقبل' : 'Books, templates, courses, and tools for engineers of the future'}</p>
          </motion.div>
        </div>
      </section>

      <motion.button onClick={() => setCartOpen(true)} className="fixed bottom-6 left-6 z-50 flex items-center gap-2 px-5 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-full shadow-lg shadow-amber-500/30 hover:shadow-amber-500/50 transition-shadow" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
        <ShoppingCart className="w-5 h-5" />
        {cart.length > 0 && (<span className="bg-slate-950 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">{cart.reduce((sum, item) => sum + item.quantity, 0)}</span>)}
      </motion.button>

      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map((cat) => (
              <button key={cat.key} onClick={() => setActiveCategory(cat.key)} className={`px-5 py-2.5 rounded-lg font-medium transition-all ${activeCategory === cat.key ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/25' : 'bg-slate-800/50 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700'}`}>
                {cat.label}
              </button>
            ))}
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <motion.div key={product.id} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="group bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden hover:border-amber-500/30 transition-all">
                <div className="relative h-52 overflow-hidden">
                  <img src={product.image} alt={product.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60" />
                  {product.oldPrice && (<span className="absolute top-3 right-3 px-2 py-1 bg-red-500 text-white text-xs font-bold rounded">{isRTL ? 'خصم' : 'SALE'}</span>)}
                  <button className="absolute top-3 left-3 w-9 h-9 bg-slate-900/80 backdrop-blur-sm rounded-full flex items-center justify-center text-slate-400 hover:text-red-400 transition-colors"><Heart className="w-4 h-4" /></button>
                </div>

                <div className="p-5">
                  <div className="flex items-center gap-1 mb-2"><Star className="w-4 h-4 text-amber-400 fill-amber-400" /><span className="text-white text-sm font-medium">{product.rating}</span><span className="text-slate-500 text-xs">({product.reviews})</span></div>
                  <h3 className="text-white font-medium mb-3 line-clamp-2 group-hover:text-amber-400 transition-colors h-12">{product.title}</h3>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2"><span className="text-amber-400 font-bold">{product.price}</span>{product.oldPrice && (<span className="text-slate-500 text-sm line-through">{product.oldPrice}</span>)}</div>
                  </div>
                  <motion.button onClick={() => addToCart(product)} className={`w-full mt-4 flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg text-sm`} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <ShoppingCart className="w-4 h-4" />{isRTL ? 'أضف للسلة' : 'Add to Cart'}
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {cartOpen && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50" onClick={() => setCartOpen(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <motion.div initial={{ x: isRTL ? -100 : 100 }} animate={{ x: 0 }} exit={{ x: isRTL ? -100 : 100 }} className={`absolute top-0 bottom-0 ${isRTL ? 'left-0' : 'right-0'} w-full max-w-md bg-slate-900 border-l border-slate-800 flex flex-col`} onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-6 border-b border-slate-800">
              <h2 className="text-xl font-bold text-white flex items-center gap-2"><ShoppingCart className="w-5 h-5 text-amber-400" />{isRTL ? 'سلة التسوق' : 'Shopping Cart'}</h2>
              <button onClick={() => setCartOpen(false)} className="p-2 text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {cart.length === 0 ? (
                <div className="text-center py-12"><ShoppingCart className="w-16 h-16 text-slate-700 mx-auto mb-4" /><p className="text-slate-400">{isRTL ? 'السلة فارغة' : 'Cart is empty'}</p></div>
              ) : (
                cart.map((item) => (
                  <div key={item.id} className="flex gap-4 bg-slate-800/50 rounded-xl p-4">
                    <div className="flex-1"><h4 className="text-white font-medium text-sm mb-2">{item.title}</h4><p className="text-amber-400 font-bold">{item.price}</p></div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => updateCartQuantity(item.id, -1)} className="w-7 h-7 bg-slate-700 rounded flex items-center justify-center text-white hover:bg-slate-600"><Minus className="w-3 h-3" /></button>
                      <span className="text-white w-6 text-center">{item.quantity}</span>
                      <button onClick={() => updateCartQuantity(item.id, 1)} className="w-7 h-7 bg-slate-700 rounded flex items-center justify-center text-white hover:bg-slate-600"><Plus className="w-3 h-3" /></button>
                      <button onClick={() => removeFromCart(item.id)} className="w-7 h-7 bg-red-500/20 rounded flex items-center justify-center text-red-400 hover:bg-red-500/30 ml-2"><X className="w-3 h-3" /></button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div className="p-6 border-t border-slate-800 space-y-4">
                <div className="flex justify-between text-lg"><span className="text-slate-400">{isRTL ? 'الإجمالي' : 'Total'}</span><span className="text-white font-bold">${cartTotal.toFixed(2)}</span></div>
                <motion.button className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-xl" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>{isRTL ? 'إتمام الشراء' : 'Checkout'}</motion.button>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}

      <Footer />
    </div>
  );
};

export default Store;