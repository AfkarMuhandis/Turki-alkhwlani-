import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Home, ArrowLeft } from 'lucide-react';

const NotFound: React.FC = () => {
  const { isRTL } = useLanguage();

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />
      
      <section className="pt-32 pb-20 flex items-center justify-center min-h-[80vh]">
        <div className="text-center px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <div className="text-[150px] sm:text-[200px] font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-amber-600 leading-none">
              404
            </div>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-3xl sm:text-4xl font-bold text-white mb-4"
          >
            {isRTL ? 'الصفحة غير موجودة' : 'Page Not Found'}
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-slate-400 mb-8 max-w-md mx-auto"
          >
            {isRTL 
              ? 'عذراً، الصفحة التي تبحث عنها غير موجودة أو تم نقلها.'
              : 'Sorry, the page you are looking for does not exist or has been moved.'}
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="flex flex-wrap justify-center gap-4"
          >
            <a
              href="/"
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg shadow-lg shadow-amber-500/25 hover:shadow-amber-500/40 transition-shadow"
            >
              <Home className="w-5 h-5" />
              {isRTL ? 'الرئيسية' : 'Home'}
            </a>
            <button
              onClick={() => window.history.back()}
              className="inline-flex items-center gap-2 px-6 py-3 bg-slate-800/50 border border-slate-700 text-white font-medium rounded-lg hover:border-amber-500/50 transition-colors"
            >
              <ArrowLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
              {isRTL ? 'رجوع' : 'Go Back'}
            </button>
          </motion.div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

export default NotFound;