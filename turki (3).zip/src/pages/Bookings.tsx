import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import {
  Calendar, Clock, User, Mail, Phone,
  MessageSquare, CheckCircle, ChevronLeft, ChevronRight,
  ArrowRight
} from 'lucide-react';

const Bookings: React.FC = () => {
  const { isRTL } = useLanguage();
  const [selectedDate, setSelectedDate] = useState<number | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '', email: '', phone: '', service: '', notes: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const services = [
    isRTL ? 'استشارة هندسية' : 'Engineering Consultation',
    isRTL ? 'مراجعة تصميم' : 'Design Review',
    isRTL ? 'جلسة تدريب' : 'Training Session',
    isRTL ? 'تقييم مشروع' : 'Project Evaluation',
    isRTL ? 'استشارة مجانية' : 'Free Consultation',
  ];

  // Generate current month dates
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = new Date(year, month, 1).getDay();
  
  const dates = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const timeSlots = ['09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00', '17:00'];
  
  const monthNames = isRTL 
    ? ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']
    : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-slate-950">
        <Header />
        <section className="pt-32 pb-20 flex items-center justify-center min-h-[80vh]">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 0 }} className="text-center max-w-md mx-auto px-4">
            <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-4">{isRTL ? 'تم الحجز بنجاح!' : 'Booking Confirmed!'}</h2>
            <p className="text-slate-400 mb-8">
              {isRTL 
                ? 'سيتم إرسال تأكيد الحجز إلى بريدك الإلكتروني قريباً'
                : 'A booking confirmation will be sent to your email shortly'}
            </p>
            <motion.a href="/" className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg" whileHover={{ scale: 1.02 }}>
              {isRTL ? 'العودة للرئيسية' : 'Back to Home'}
              <ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
            </motion.a>
          </motion.div>
        </section>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-12 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'احجز موعدك' : 'Book Your Appointment'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              {isRTL 
                ? 'اختر التاريخ والوقت المناسب لك واحجز استشارتك المجانية'
                : 'Choose the date and time that suits you and book your free consultation'}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Progress Steps */}
      <section className="py-8">
        <div className="max-w-3xl mx-auto px-4">
          <div className="flex items-center justify-center gap-4">
            {[1, 2, 3].map((s) => (
              <React.Fragment key={s}>
                <div className={`flex items-center gap-2 ${step >= s ? 'text-amber-400' : 'text-slate-600'}`}>
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${step >= s ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950' : 'bg-slate-800 text-slate-500'}`}>
                    {step > s ? <CheckCircle className="w-5 h-5" /> : s}
                  </div>
                  <span className="hidden sm:block font-medium">
                    {s === 1 ? (isRTL ? 'الموعد' : 'Date & Time') : s === 2 ? (isRTL ? 'البيانات' : 'Your Info') : (isRTL ? 'التأكيد' : 'Confirm')}
                  </span>
                </div>
                {s < 3 && <div className={`flex-1 h-px max-w-16 ${step > s ? 'bg-amber-500' : 'bg-slate-800'}`} />}
              </React.Fragment>
            ))}
          </div>
        </div>
      </section>

      {/* Booking Form */}
      <section className="pb-24">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            key={step}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 sm:p-10"
          >
            {/* Step 1: Date & Time Selection */}
            {step === 1 && (
              <div>
                <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
                  <Calendar className="w-7 h-7 text-amber-400" />
                  {isRTL ? 'اختر الموعد المناسب' : 'Choose Your Preferred Time'}
                </h2>
                
                {/* Calendar Header */}
                <div className="flex items-center justify-between mb-6">
                  <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
                    <ChevronLeft className={`w-5 h-5 text-slate-400 ${isRTL ? '' : 'rotate-180'}`} />
                  </button>
                  <h3 className="text-xl font-bold text-white">
                    {monthNames[month]} {year}
                  </h3>
                  <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors">
                    <ChevronRight className={`w-5 h-5 text-slate-400 ${isRTL ? 'rotate-180' : ''}`} />
                  </button>
                </div>

                {/* Calendar Grid */}
                <div className="grid grid-cols-7 gap-2 mb-8">
                  {(isRTL ? ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'] : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']).map((day) => (
                    <div key={day} className="text-center text-sm text-slate-500 py-2 font-medium">{day}</div>
                  ))}
                  {Array.from({ length: firstDayOfMonth }, (_, i) => (
                    <div key={`empty-${i}`} />
                  ))}
                  {dates.map((date) => (
                    <button
                      key={date}
                      onClick={() => setSelectedDate(date)}
                      disabled={date < today.getDate()}
                      className={`aspect-square rounded-xl font-medium transition-all ${
                        selectedDate === date
                          ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/25'
                          : date >= today.getDate()
                            ? 'bg-slate-800/50 text-white hover:bg-slate-700'
                            : 'text-slate-700 cursor-not-allowed'
                      }`}
                    >
                      {date}
                    </button>
                  ))}
                </div>

                {/* Time Slots */}
                {selectedDate && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}>
                    <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <Clock className="w-5 h-5 text-amber-400" />
                      {isRTL ? 'اختر الوقت' : 'Select Time'}
                    </h4>
                    <div className="grid grid-cols-4 gap-3 mb-8">
                      {timeSlots.map((time) => (
                        <button
                          key={time}
                          onClick={() => setSelectedTime(time)}
                          className={`py-3 rounded-xl font-medium transition-all ${
                            selectedTime === time
                              ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg'
                              : 'bg-slate-800/50 text-white hover:bg-slate-700 border border-slate-700'
                          }`}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </motion.div>
                )}

                <div className="flex justify-end">
                  <motion.button
                    onClick={() => selectedDate && selectedTime && setStep(2)}
                    disabled={!selectedDate || !selectedTime}
                    className={`flex items-center gap-2 px-8 py-3 rounded-lg font-bold transition-all ${
                      selectedDate && selectedTime
                        ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg shadow-amber-500/25'
                        : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    }`}
                    whileHover={selectedDate && selectedTime ? { scale: 1.02 } : {}}
                  >
                    {isRTL ? 'التالي' : 'Next'}
                    <ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                  </motion.button>
                </div>
              </div>
            )}

            {/* Step 2: Personal Info */}
            {step === 2 && (
              <form onSubmit={(e) => { e.preventDefault(); setStep(3); }}>
                <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
                  <User className="w-7 h-7 text-amber-400" />
                  {isRTL ? 'معلوماتك الشخصية' : 'Your Information'}
                </h2>
                
                <div className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        {isRTL ? 'الاسم الكامل' : 'Full Name'} *
                      </label>
                      <div className="relative">
                        <User className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                        <input
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({...formData, name: e.target.value})}
                          className={`w-full py-3 px-${isRTL ? '10 pr-12' : '10 pl-12'} bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors`}
                          placeholder={isRTL ? 'أدخل اسمك الكامل' : 'Enter your full name'}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        {isRTL ? 'البريد الإلكتروني' : 'Email Address'} *
                      </label>
                      <div className="relative">
                        <Mail className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          className={`w-full py-3 px-${isRTL ? '10 pr-12' : '10 pl-12'} bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors`}
                          placeholder={isRTL ? 'example@email.com' : 'example@email.com'}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        {isRTL ? 'رقم الهاتف' : 'Phone Number'} *
                      </label>
                      <div className="relative">
                        <Phone className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 ${isRTL ? 'right-3' : 'left-3'}`} />
                        <input
                          type="tel"
                          required
                          value={formData.phone}
                          onChange={(e) => setFormData({...formData, phone: e.target.value})}
                          className={`w-full py-3 px-${isRTL ? '10 pr-12' : '10 pl-12'} bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors`}
                          placeholder={isRTL ? '+966 5XX XXX XXXX' : '+966 5XX XXX XXXX'}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-300 mb-2">
                        {isRTL ? 'نوع الخدمة' : 'Service Type'} *
                      </label>
                      <select
                        required
                        value={formData.service}
                        onChange={(e) => setFormData({...formData, service: e.target.value})}
                        className="w-full py-3 px-4 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-amber-500 transition-colors"
                      >
                        <option value="">{isRTL ? 'اختر الخدمة' : 'Select Service'}</option>
                        {services.map((service) => (
                          <option key={service} value={service}>{service}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-300 mb-2">
                      {isRTL ? 'ملاحظات إضافية' : 'Additional Notes'}
                    </label>
                    <textarea
                      rows={4}
                      value={formData.notes}
                      onChange={(e) => setFormData({...formData, notes: e.target.value})}
                      className="w-full py-3 px-4 bg-slate-800/50 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors resize-none"
                      placeholder={isRTL ? 'اكتب أي ملاحظات أو استفسارات...' : 'Write any notes or inquiries...'}
                    />
                  </div>
                </div>

                <div className="flex justify-between mt-8">
                  <button type="button" onClick={() => setStep(1)} className="flex items-center gap-2 px-6 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors">
                    <ArrowRight className={`w-5 h-5 ${isRTL ? '' : 'rotate-180'}`} />
                    {isRTL ? 'السابق' : 'Previous'}
                  </button>
                  <motion.button type="submit" className="flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg shadow-lg shadow-amber-500/25" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    {isRTL ? 'التالي' : 'Next'}
                    <ArrowRight className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
                  </motion.button>
                </div>
              </form>
            )}

            {/* Step 3: Confirmation */}
            {step === 3 && (
              <div>
                <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-3">
                  <CheckCircle className="w-7 h-7 text-amber-400" />
                  {isRTL ? 'تأكيد الحجز' : 'Confirm Booking'}
                </h2>
                
                <div className="space-y-6 mb-8">
                  <div className="bg-slate-800/30 rounded-xl p-6 space-y-4">
                    <div className="flex items-center justify-between py-3 border-b border-slate-700">
                      <span className="text-slate-400 flex items-center gap-2"><Calendar className="w-4 h-4" />{isRTL ? 'التاريخ' : 'Date'}</span>
                      <span className="text-white font-medium">{selectedDate} {monthNames[month]} {year}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-700">
                      <span className="text-slate-400 flex items-center gap-2"><Clock className="w-4 h-4" />{isRTL ? 'الوقت' : 'Time'}</span>
                      <span className="text-white font-medium">{selectedTime}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-700">
                      <span className="text-slate-400 flex items-center gap-2"><User className="w-4 h-4" />{isRTL ? 'الاسم' : 'Name'}</span>
                      <span className="text-white font-medium">{formData.name}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-700">
                      <span className="text-slate-400 flex items-center gap-2"><Mail className="w-4 h-4" />{isRTL ? 'البريد' : 'Email'}</span>
                      <span className="text-white font-medium">{formData.email}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-700">
                      <span className="text-slate-400 flex items-center gap-2"><Phone className="w-4 h-4" />{isRTL ? 'الهاتف' : 'Phone'}</span>
                      <span className="text-white font-medium">{formData.phone}</span>
                    </div>
                    <div className="flex items-center justify-between py-3">
                      <span className="text-slate-400 flex items-center gap-2"><MessageSquare className="w-4 h-4" />{isRTL ? 'الخدمة' : 'Service'}</span>
                      <span className="text-white font-medium">{formData.service}</span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-between">
                  <button onClick={() => setStep(2)} className="flex items-center gap-2 px-6 py-3 bg-slate-800 text-white rounded-lg hover:bg-slate-700 transition-colors">
                    <ArrowRight className={`w-5 h-5 ${isRTL ? '' : 'rotate-180'}`} />
                    {isRTL ? 'السابق' : 'Previous'}
                  </button>
                  <motion.button onClick={handleSubmit} className="flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold rounded-lg shadow-lg shadow-green-500/25" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <CheckCircle className="w-5 h-5" />
                    {isRTL ? 'تأكيد الحجز' : 'Confirm Booking'}
                  </motion.button>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Bookings;