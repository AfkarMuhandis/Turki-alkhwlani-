import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { 
  Search, Calendar, Clock, ArrowRight,
  Tag, User, ChevronLeft, ChevronRight
} from 'lucide-react';

const Blog: React.FC = () => {
  const { isRTL } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { key: 'all', label: isRTL ? 'الكل' : 'All' },
    { key: 'engineering', label: isRTL ? 'هندسة' : 'Engineering' },
    { key: 'technology', label: isRTL ? 'تقنية' : 'Technology' },
    { key: 'management', label: isRTL ? 'إدارة' : 'Management' },
    { key: 'tutorials', label: isRTL ? 'دروس' : 'Tutorials' },
  ];

  const articles = [
    {
      id: 1,
      title: isRTL ? 'أحدث تقنيات البناء المستدام في 2024' : 'Latest Sustainable Building Technologies in 2024',
      excerpt: isRTL 
        ? 'اكتشف أحدث التقنيات والاتجاهات في مجال البناء المستدام والصديق للبيئة، وكيف يمكن تطبيقها في مشاريعك.'
        : 'Discover the latest technologies and trends in sustainable and eco-friendly construction, and how to apply them in your projects.',
      image: 'https://images.unsplash.com/photo-1504307651250-9786c063a6c7?w=800',
      category: 'engineering',
      author: isRTL ? 'م. أحمد الراشد' : 'Eng. Ahmed Al-Rashid',
      date: isRTL ? '15 يناير 2024' : 'Jan 15, 2024',
      readTime: isRTL ? '8 دقائق' : '8 min read',
      tags: [isRTL ? 'بناء مستدام' : 'Sustainable', isRTL ? 'بيئة' : 'Eco-friendly'],
    },
    {
      id: 2,
      title: isRTL ? 'دليل شامل لإدارة المشاريع الهندسية بكفاءة' : 'Comprehensive Guide to Efficient Engineering Project Management',
      excerpt: isRTL
        ? 'نصائح وإرشادات عملية لإدارة المشاريع الهندسية بكفاءة عالية وتجنب الأخطاء الشائعة.'
        : 'Practical tips and guidelines for managing engineering projects efficiently and avoiding common mistakes.',
      image: 'https://images.unsplash.com/photo-1531834685032-cd5634b1f8e7?w=800',
      category: 'management',
      author: isRTL ? 'م. سارة المنصور' : 'Eng. Sara Al-Mansour',
      date: isRTL ? '12 يناير 2024' : 'Jan 12, 2024',
      readTime: isRTL ? '12 دقيقة' : '12 min read',
      tags: [isRTL ? 'إدارة مشاريع' : 'Project Mgmt', isRTL ? 'كفاءة' : 'Efficiency'],
    },
    {
      id: 3,
      title: isRTL ? 'مستقبل الهندسة المدنية: الذكاء الاصطناعي والأتمتة' : 'Future of Civil Engineering: AI & Automation',
      excerpt: isRTL
        ? 'كيف يغير الذكاء الاصطناعي والأتمتة وجه الهندسة المدنية وماذا يعني ذلك للمهندسين.'
        : 'How AI and automation are changing the face of civil engineering and what it means for engineers.',
      image: 'https://images.unsplash.com/photo-1581094794329-c8112a89af5a?w=800',
      category: 'technology',
      author: isRTL ? 'م. خالد الشمري' : 'Eng. Khaled Al-Shammari',
      date: isRTL ? '10 يناير 2024' : 'Jan 10, 2024',
      readTime: isRTL ? '10 دقائق' : '10 min read',
      tags: [isRTL ? 'ذكاء اصطناعي' : 'AI', isRTL ? 'أتمتة' : 'Automation'],
    },
    {
      id: 4,
      title: isRTL ? 'تعلم AutoCAD من الصفر إلى الاحتراف' : 'Learn AutoCAD from Zero to Pro',
      excerpt: isRTL
        ? 'دليل تعليمي شامل لتعلم برنامج AutoCAD خطوة بخطوة مع أمثلة عملية ومشاريع حقيقية.'
        : 'Comprehensive tutorial guide for learning AutoCAD step by step with practical examples and real projects.',
      image: 'https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?w=800',
      category: 'tutorials',
      author: isRTL ? 'م. نورة القحطاني' : 'Eng. Noura Al-Qahtani',
      date: isRTL ? '8 يناير 2024' : 'Jan 8, 2024',
      readTime: isRTL ? '20 دقيقة' : '20 min read',
      tags: [isRTL ? 'AutoCAD' : 'AutoCAD', isRTL ? 'تعلم' : 'Learning'],
    },
    {
      id: 5,
      title: isRTL ? 'أهم المعايير الدولية في تصميم الخرسانة المسلحة' : 'International Standards in Reinforced Concrete Design',
      excerpt: isRTL
        ? 'مراجعة شاملة لأهم المعايير والمواصفات الدولية في تصميم المنشآت الخرسانية المسلحة.'
        : 'Comprehensive review of the most important international standards and specifications in reinforced concrete design.',
      image: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800',
      category: 'engineering',
      author: isRTL ? 'م. أحمد الراشد' : 'Eng. Ahmed Al-Rashid',
      date: isRTL ? '5 يناير 2024' : 'Jan 5, 2024',
      readTime: isRTL ? '15 دقيقة' : '15 min read',
      tags: [isRTL ? 'خرسانة' : 'Concrete', isRTL ? 'معايير' : 'Standards'],
    },
    {
      id: 6,
      title: isRTL ? 'BIM: ثورة التصميم البنيوي ثلاثي الأبعاد' : 'BIM: The 3D Structural Design Revolution',
      excerpt: isRTL
        ? 'كيف يُحدث نموذج Building Information Modeling (BIM) ثورة في صناعة البناء والتشييد.'
        : 'How Building Information Modeling (BIM) is revolutionizing the construction industry.',
      image: 'https://images.unsplash.com/photo-1504307651250-9786c063a6c7?w=800',
      category: 'technology',
      author: isRTL ? 'م. سارة المنصور' : 'Eng. Sara Al-Mansour',
      date: isRTL ? '3 يناير 2024' : 'Jan 3, 2024',
      readTime: isRTL ? '9 دقائق' : '9 min read',
      tags: [isRTL ? 'BIM' : 'BIM', isRTL ? 'تصميم' : 'Design'],
    },
  ];

  const filteredArticles = articles.filter(article => {
    const matchesCategory = activeCategory === 'all' || article.category === activeCategory;
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          article.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-amber-400">{isRTL ? 'المدونة' : 'Blog'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed mb-10">
              {isRTL 
                ? 'مقالات ودروس وقصص من عالم الهندسة'
                : 'Articles, tutorials, and stories from the world of engineering'}
            </p>
            
            {/* Search Bar */}
            <div className="relative max-w-xl mx-auto">
              <Search className={`absolute top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 ${isRTL ? 'right-4' : 'left-4'}`} />
              <input
                type="text"
                placeholder={isRTL ? 'ابحث في المقالات...' : 'Search articles...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full py-4 px-12 bg-slate-900/80 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-colors"
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((cat) => (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className={`px-5 py-2 rounded-lg font-medium transition-all ${
                  activeCategory === cat.key
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 shadow-lg'
                    : 'bg-slate-800/50 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Article */}
      {filteredArticles.length > 0 && (
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.a href="#" className="group grid lg:grid-cols-2 gap-8 bg-slate-900/30 border border-slate-800 rounded-2xl overflow-hidden hover:border-amber-500/20 transition-colors">
              <div className="relative h-96 lg:h-auto overflow-hidden">
                <img 
                  src={filteredArticles[0].image} 
                  alt={filteredArticles[0].title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-transparent to-transparent lg:hidden" />
                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-amber-500 text-slate-950 text-xs font-bold rounded-full">
                    {isRTL ? 'مميز' : 'Featured'}
                  </span>
                </div>
              </div>
              <div className="p-8 flex flex-col justify-center">
                <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                  <span className="px-3 py-1 bg-amber-500/10 text-amber-400 rounded-full">{categories.find(c => c.key === filteredArticles[0].category)?.label}</span>
                  <span className="flex items-center gap-1"><Calendar className="w-4 h-4" />{filteredArticles[0].date}</span>
                  <span className="flex items-center gap-1"><Clock className="w-4 h-4" />{filteredArticles[0].readTime}</span>
                </div>
                <h2 className="text-2xl lg:text-3xl font-bold text-white mb-4 group-hover:text-amber-400 transition-colors">
                  {filteredArticles[0].title}
                </h2>
                <p className="text-slate-400 mb-6 leading-relaxed">{filteredArticles[0].excerpt}</p>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <User className="w-5 h-5 text-amber-400" />
                    <span className="text-slate-300">{filteredArticles[0].author}</span>
                  </div>
                  <motion.span className="flex items-center gap-1 text-amber-400 font-medium" whileHover={{ x: isRTL ? -5 : 5 }}>
                    {isRTL ? 'اقرأ المزيد' : 'Read More'}
                    <ArrowRight className={`w-4 h-4 ${isRTL ? '' : 'rotate-180'}`} />
                  </motion.span>
                </div>
              </div>
            </motion.a>
          </div>
        </section>
      )}

      {/* Articles Grid */}
      <section className="pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-white mb-8">{isRTL ? 'أحدث المقالات' : 'Latest Articles'}</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {(filteredArticles.length > 0 ? filteredArticles.slice(1) : filteredArticles).map((article) => (
              <motion.article
                key={article.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="group bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden hover:border-amber-500/20 transition-all"
              >
                <div className="relative h-52 overflow-hidden">
                  <img 
                    src={article.image} 
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-transparent opacity-60" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="px-3 py-1 bg-amber-500/90 text-slate-950 text-xs font-bold rounded-full">
                      {categories.find(c => c.key === article.category)?.label}
                    </span>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center gap-3 text-sm text-slate-500 mb-3">
                    <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{article.date}</span>
                    <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{article.readTime}</span>
                  </div>
                  
                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-amber-400 transition-colors line-clamp-2">
                    {article.title}
                  </h3>
                  <p className="text-slate-400 text-sm line-clamp-2 mb-4">{article.excerpt}</p>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-500" />
                      <span className="text-slate-400 text-sm">{article.author}</span>
                    </div>
                    <motion.span className="flex items-center gap-1 text-amber-400 text-sm font-medium" whileHover={{ x: isRTL ? -3 : 3 }}>
                      {isRTL ? 'اقرأ' : 'Read'}
                      <ArrowRight className={`w-3.5 h-3.5 ${isRTL ? '' : 'rotate-180'}`} />
                    </motion.span>
                  </div>
                </div>
              </motion.article>
            ))}
          </div>

          {filteredArticles.length === 0 && (
            <div className="text-center py-16">
              <p className="text-slate-400 text-lg">{isRTL ? 'لا توجد مقالات مطابقة' : 'No matching articles found'}</p>
            </div>
          )}

          {/* Pagination */}
          {filteredArticles.length > 0 && (
            <div className="flex justify-center mt-12 gap-2">
              <button className="p-2 bg-slate-800/50 border border-slate-700 rounded-lg text-slate-400 hover:text-white hover:border-amber-500/50 transition-colors">
                <ChevronRight className={`w-5 h-5 ${isRTL ? '' : 'rotate-180'}`} />
              </button>
              {[1, 2, 3].map((page) => (
                <button key={page} className={`w-10 h-10 rounded-lg font-medium transition-all ${page === 1 ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950' : 'bg-slate-800/50 border border-slate-700 text-slate-400 hover:text-white'}`}>
                  {page}
                </button>
              ))}
              <button className="p-2 bg-slate-800/50 border border-slate-700 rounded-lg text-slate-400 hover:text-white hover:border-amber-500/50 transition-colors">
                <ChevronLeft className={`w-5 h-5 ${isRTL ? 'rotate-180' : ''}`} />
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-16 bg-slate-900/30 border-y border-amber-500/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">{isRTL ? 'اشترك للحصول على آخر التحديثات' : 'Subscribe for Latest Updates'}</h2>
          <p className="text-slate-400 mb-6">{isRTL ? 'احصل على أحدث المقالات مباشرة في بريدك' : 'Get the latest articles directly in your inbox'}</p>
          <div className="flex max-w-md mx-auto gap-3">
            <input type="email" placeholder={isRTL ? 'بريدك الإلكتروني' : 'Your email'} className="flex-1 px-4 py-3 bg-slate-900 border border-slate-700 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-amber-500" />
            <motion.button className="px-6 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-lg" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              {isRTL ? 'اشتراك' : 'Subscribe'}
            </motion.button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Blog;