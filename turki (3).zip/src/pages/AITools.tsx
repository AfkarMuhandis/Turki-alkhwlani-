import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { Send, Bot, Sparkles, Copy, RefreshCw, Download } from 'lucide-react';

const AITools: React.FC = () => {
  const { isRTL } = useLanguage();
  const [activeTool, setActiveTool] = useState('assistant');
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const tools = [
    { key: 'assistant', label: isRTL ? 'المساعد الذكي' : 'AI Assistant', icon: Bot },
    { key: 'summarize', label: isRTL ? 'تلخيص' : 'Summarize', icon: Sparkles },
    { key: 'translate', label: isRTL ? 'ترجمة' : 'Translate', icon: RefreshCw },
    { key: 'generate', label: isRTL ? 'توليد محتوى' : 'Generate Content', icon: Download },
  ];

  const handleGenerate = () => {
    if (!input.trim()) return;
    setIsLoading(true);
    
    // Simulate AI response
    setTimeout(() => {
      const responses: Record<string, string> = {
        assistant: isRTL 
          ? `شكراً لسؤالك! بناءً على استفسارك حول "${input}", إليك بعض النقاط المهمة:\n\n1. يمكنني مساعدتك في الاستفسارات الهندسية\n2. أستطيع تقديم توصيات للخدمات المناسبة\n3. يمكنني الإجابة على أسئلتك التقنية\n\nهل لديك سؤال محدد آخر؟`
          : `Thank you for your question! Based on your inquiry about "${input}", here are some key points:\n\n1. I can help with engineering inquiries\n2. I can provide recommendations for suitable services\n3. I can answer your technical questions\n\nDo you have another specific question?`,
        summarize: isRTL 
          ? `ملخص:\n${input.substring(0, 100)}...\n\nالنقاط الرئيسية:\n- الفكرة الأساسية تدور حول الموضوع المذكور\n- يمكن تطبيق المفاهيم في مشاريع هندسية متعددة`
          : `Summary:\n${input.substring(0, 100)}...\n\nKey points:\n- The core idea revolves around the mentioned topic\n- Concepts can be applied in various engineering projects`,
        translate: isRTL 
          ? `الترجمة:\n\n"${input}"\n\nTranslation: This is a simulated translation of your text.`
          : `Translation:\n\n"${input}"\n\nهذه ترجمة محاكاة لنصك.`,
        generate: isRTL 
          ? `المحتوى المولد:\n\n# ${input}\n\n## مقدمة\nهذا محتوى مولد آلياً بناءً على طلبك.\n\n## النقاط الرئيسية\n1. النقطة الأولى\n2. النقطة الثانية\n3. النقطة الثالثة\n\n## الخلاصة\nيمكنك استخدام هذا المحتوى كنقطة بداية.`
          : `Generated Content:\n\n# ${input}\n\n## Introduction\nThis is AI-generated content based on your request.\n\n## Key Points\n1. First point\n2. Second point\n3. Third point\n\n## Conclusion\nYou can use this content as a starting point.`,
      };
      setOutput(responses[activeTool] || responses.assistant);
      setIsLoading(false);
    }, 1500);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(output);
  };

  const features = [
    { title: isRTL ? 'استشارات هندسية ذكية' : 'Smart Engineering Consultations', desc: isRTL ? 'احصل على إجابات فورية لأسئلتك الهندسية' : 'Get instant answers to your engineering questions' },
    { title: isRTL ? 'تلخيص المقالات' : 'Article Summarization', desc: isRTL ? 'لخص المقالات الطويلة في ثوانٍ' : 'Summarize long articles in seconds' },
    { title: isRTL ? 'ترجمة فورية' : 'Instant Translation', desc: isRTL ? 'ترجم النصوص بين العربية والإنجليزية' : 'Translate text between Arabic and English' },
    { title: isRTL ? 'توليد المحتوى' : 'Content Generation', desc: isRTL ? 'أنشئ محتوى احترافي بسرعة' : 'Create professional content quickly' },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center max-w-3xl mx-auto">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 0 }} className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Bot className="w-10 h-10 text-white" />
            </motion.div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">{isRTL ? 'أدوات الذكاء الاصطناعي' : 'AI Tools'}</span>
            </h1>
            <p className="text-xl text-slate-400 leading-relaxed">
              {isRTL 
                ? 'استفد من قوة الذكاء الاصطناعي في مشاريعك الهندسية'
                : 'Leverage the power of AI in your engineering projects'}
            </p>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((feature, i) => (
              <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }} className="bg-slate-900/50 border border-slate-800 rounded-xl p-4 text-center hover:border-purple-500/30 transition-colors">
                <h3 className="text-white font-medium mb-1">{feature.title}</h3>
                <p className="text-slate-400 text-sm">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* AI Tool Interface */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden">
            {/* Tool Tabs */}
            <div className="flex border-b border-slate-800 overflow-x-auto">
              {tools.map((tool) => (
                <button
                  key={tool.key}
                  onClick={() => setActiveTool(tool.key)}
                  className={`flex items-center gap-2 px-6 py-4 font-medium transition-all whitespace-nowrap ${
                    activeTool === tool.key
                      ? 'bg-slate-800 text-white border-b-2 border-purple-500'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <tool.icon className="w-4 h-4" />
                  {tool.label}
                </button>
              ))}
            </div>

            {/* Input Area */}
            <div className="p-6">
              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  {isRTL ? 'أدخل النص أو السؤال' : 'Enter your text or question'}
                </label>
                <textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  rows={4}
                  className="w-full px-4 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors resize-none"
                  placeholder={isRTL ? 'اكتب هنا...' : 'Type here...'}
                />
              </div>

              <motion.button
                onClick={handleGenerate}
                disabled={isLoading || !input.trim()}
                className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold transition-all ${
                  isLoading || !input.trim()
                    ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                    : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:shadow-lg hover:shadow-purple-500/25'
                }`}
                whileHover={!isLoading && input.trim() ? { scale: 1.01 } : {}}
                whileTap={!isLoading && input.trim() ? { scale: 0.99 } : {}}
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    {isRTL ? 'جاري المعالجة...' : 'Processing...'}
                  </>
                ) : (
                  <>\n                    <Sparkles className="w-5 h-5" />
                    {isRTL ? 'توليد' : 'Generate'}
                  </>
                )}
              </motion.button>

              {/* Output Area */}
              {output && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-6">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-sm font-medium text-slate-300">{isRTL ? 'النتيجة' : 'Result'}</label>
                    <button onClick={handleCopy} className="flex items-center gap-1 text-sm text-slate-400 hover:text-purple-400 transition-colors">
                      <Copy className="w-4 h-4" />
                      {isRTL ? 'نسخ' : 'Copy'}
                    </button>
                  </div>
                  <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-4">
                    <pre className="text-slate-300 whitespace-pre-wrap font-sans text-sm">{output}</pre>
                  </div>
                </motion.div>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4 text-center">
            <p className="text-yellow-400 text-sm">
              {isRTL 
                ? '⚠️ هذه الأدوات تجريبية وقد تحتوي على أخطاء. يرجى التحقق من المعلومات قبل استخدامها.'
                : '⚠️ These tools are experimental and may contain errors. Please verify information before use.'}
            </p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default AITools;