import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '../lib/i18n';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Terms: React.FC = () => {
  const { isRTL } = useLanguage();

  const sections = [
    {
      title: isRTL ? '1. قبول الشروط' : '1. Acceptance of Terms',
      content: isRTL
        ? 'باستخدامك لهذا الموقع، فإنك توافق على الالتزام بهذه الشروط وال_conditions.'
        : 'By using this website, you agree to comply with these terms and conditions.'
    },
    {
      title: isRTL ? '2. الخدمات المقدمة' : '2. Services Provided',
      content: isRTL
        ? 'نقدم خدمات هندسية، استشارات، منتجات رقمية، وأدوات. قد نغير الخدمات دون إشعار مسبق.'
        : 'We provide engineering services, consultations, digital products, and tools. We may change services without prior notice.'
    },
    {
      title: isRTL ? '3. التزامات المستخدم' : '3. User Obligations',
      content: isRTL
        ? 'يجب عليك استخدام الموقع بشكل قانوني، عدم انتهاك حقوق الملكية الفكرية، وعدم إساءة استخدام الخدمات.'
        : 'You must use the site lawfully, not violate intellectual property rights, and not misuse the services.'
    },
    {
      title: isRTL ? '4. الملكية الفكرية' : '4. Intellectual Property',
      content: isRTL
        ? 'جميع المحتويات والتصاميم والعلامات التجارية ملكنا ولا يجوز استخدامها دون إذن مكتوب.'
        : 'All content, designs, and trademarks are our property and may not be used without written permission.'
    },
    {
      title: isRTL ? '5. الدفع والاسترداد' : '5. Payment and Refunds',
      content: isRTL
        ? 'يجب الدفع في الوقت المحدد. سياسة الاسترداد تختلف حسب الخدمة والمنتج.'
        : 'Payment must be made on time. Refund policy varies by service and product.'
    },
    {
      title: isRTL ? '6. إخلاء المسؤولية' : '6. Disclaimer',
      content: isRTL
        ? 'المعلومات المقدمة للأغراض التعليمية فقط. نحن غير مسؤولين عن أي قرارات تُتخذ بناءً عليها.'
        : 'Information provided is for educational purposes only. We are not responsible for decisions made based on it.'
    },
    {
      title: isRTL ? '7. تحديد المسؤولية' : '7. Limitation of Liability',
      content: isRTL
        ? 'نحن غير مسؤولين عن أي أضرار مباشرة أو غير مباشرة ناتجة عن استخدام الخدمات.'
        : 'We are not liable for any direct or indirect damages resulting from the use of services.'
    },
    {
      title: isRTL ? '8. التعديلات' : '8. Modifications',
      content: isRTL
        ? 'يمكننا تعديل هذه الشروط في أي وقت. الاستمرار في استخدام الموقع يعني قبول التعديلات.'
        : 'We may modify these terms at any time. Continued use of the site means acceptance of modifications.'
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950">
      <Header />

      <section className="relative pt-32 pb-16 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950" />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-4">
              <span className="text-amber-400">{isRTL ? 'الشروط والأحكام' : 'Terms & Conditions'}</span>
            </h1>
            <p className="text-slate-400">{isRTL ? 'آخر تحديث: يناير 2024' : 'Last updated: January 2024'}</p>
          </motion.div>

          <div className="space-y-6">
            {sections.map((section, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-slate-900/50 border border-slate-800 rounded-xl p-6"
              >
                <h2 className="text-lg font-bold text-white mb-3">{section.title}</h2>
                <p className="text-slate-400 leading-relaxed">{section.content}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Terms;